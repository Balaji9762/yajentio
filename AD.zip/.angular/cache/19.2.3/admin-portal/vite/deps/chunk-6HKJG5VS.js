import {
  InjectionToken
} from "./chunk-FN63FFFY.js";

// node_modules/@angular/material/fesm2022/input-value-accessor-8a79a24e.mjs
var MAT_INPUT_VALUE_ACCESSOR = new InjectionToken("MAT_INPUT_VALUE_ACCESSOR");

export {
  MAT_INPUT_VALUE_ACCESSOR
};
//# sourceMappingURL=chunk-6HKJG5VS.js.map

export const environment = {
  production: true,
  apiUrl: "http://3.108.126.170:8080",
  baseUrl: 'http://3.108.126.170:8080',
};

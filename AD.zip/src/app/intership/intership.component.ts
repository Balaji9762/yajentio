import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intership',
  standalone: false,
  templateUrl: './intership.component.html',
  styleUrl: './intership.component.css'
})
export class IntershipComponent implements OnInit {
  
  ngOnInit(): void {
    console.log('IntershipComponent initialized')
  }
}

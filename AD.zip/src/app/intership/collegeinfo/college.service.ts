import { Injectable } from '@angular/core';
import  { HttpClient, HttpErrorResponse } from "@angular/common/http"
import { type Observable, throwError } from "rxjs"
import { catchError } from "rxjs/operators"
//import type { College, CollegeDTO, DeleteResponse } from "../models/college.model"
import { College, CollegeDTO, DeleteResponse  } from './college';
@Injectable({
  providedIn: 'root'
})
export class CollegeService {

 private readonly API_BASE_URL = "http://3.108.126.170:8080"

  constructor(private http: HttpClient) {}

  /**
   * Get all colleges from the API
   */
  getAllColleges(): Observable<College[]> {
    return this.http.get<College[]>(`${this.API_BASE_URL}/getallcollegeinfo`).pipe(catchError(this.handleError))
  }

  /**
   * Save a new college
   */
  saveCollege(college: CollegeDTO): Observable<College> {
    return this.http.post<College>(`${this.API_BASE_URL}/savecollegeinfo`, college).pipe(catchError(this.handleError))
  }

  /**
   * Update an existing college
   */
  updateCollege(id: number, college: CollegeDTO): Observable<College> {
    return this.http
      .put<College>(`${this.API_BASE_URL}/updatecollegeinfo/${id}`, college)
      .pipe(catchError(this.handleError))
  }

  /**
   * Delete a college by ID
   */
  deleteCollege(id: number): Observable<DeleteResponse> {
    return this.http
      .delete<DeleteResponse>(`${this.API_BASE_URL}/deletecollegeinfo/${id}`)
      .pipe(catchError(this.handleError))
  }

  /**
   * Handle HTTP errors
   */
  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = "An unknown error occurred!"

    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Client Error: ${error.error.message}`
    } else {
      // Server-side error
      errorMessage = `Server Error: ${error.status} - ${error.message}`

      // Handle specific HTTP status codes
      switch (error.status) {
        case 404:
          errorMessage = "College not found"
          break
        case 500:
          errorMessage = "Internal server error"
          break
        case 0:
          errorMessage = "Unable to connect to server"
          break
      }
    }

    console.error("College Service Error:", error)
    return throwError(() => errorMessage)
  }
}

export interface College {
id: number
  clg_name: string
  address: string
  mobile_number: string
  email: string
  status: string
}

export interface CollegeDTO {
  clg_name: string
  address: string
  mobile_number: string
  email: string
  status: string
}

export interface DeleteResponse {
  message: string
}

export interface ApiResponse<T> {
  data?: T
  message?: string
  success: boolean
}

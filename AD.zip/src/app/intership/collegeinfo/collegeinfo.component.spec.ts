import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CollegeinfoComponent } from './collegeinfo.component';

describe('CollegeinfoComponent', () => {
  let component: CollegeinfoComponent;
  let fixture: ComponentFixture<CollegeinfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CollegeinfoComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CollegeinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

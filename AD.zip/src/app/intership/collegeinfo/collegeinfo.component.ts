import { Component, type OnInit, type OnDestroy } from '@angular/core';
import {  FormBuilder,  FormGroup, Validators } from "@angular/forms"
import  { MatSnackBar } from "@angular/material/snack-bar"
import  { MatDialog } from "@angular/material/dialog"
import { Subject, takeUntil } from "rxjs"
//import type { College, CollegeDTO } from "../models/college.model"
import { College, CollegeDTO } from './college';
//import type { CollegeService } from "../services/college.service"
import { CollegeService } from './college.service';
@Component({
  selector: 'app-collegeinfo',
  standalone: false,
  templateUrl: './collegeinfo.component.html',
  styleUrl: './collegeinfo.component.css'
})
export class CollegeinfoComponent
implements OnInit, OnDestroy {
  // Component properties
  colleges: College[] = []
  filteredColleges: College[] = []
  loading = false
  showForm = false
  isEditMode = false
  editingCollegeId: number | null = null
  searchTerm = ""

  // Form
  collegeForm!: FormGroup

  // Table columns
  displayedColumns: string[] = ["id", "clg_name", "address", "mobile_number", "email", "status", "actions"]

  // Status options
  statusOptions = ["Active", "Inactive"]

  // Subscription management
  private destroy$ = new Subject<void>()

  // Context menu properties
  showContextMenu = false
  contextMenuPosition = { x: 0, y: 0 }
  selectedCollege: College | null = null

  constructor(
    private collegeService: CollegeService,
    private formBuilder: FormBuilder,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
  ) {
    this.initializeForm()
  }

  ngOnInit(): void {
    this.loadColleges()
  }

  ngOnDestroy(): void {
    this.destroy$.next()
    this.destroy$.complete()
  }

  /**
   * Initialize the reactive form
   */
  private initializeForm(): void {
    this.collegeForm = this.formBuilder.group({
      clg_name: ["", [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
      address: ["", [Validators.required, Validators.minLength(5), Validators.maxLength(200)]],
      mobile_number: ["", [Validators.required, Validators.pattern(/^\d{10}$/)]],
      email: ["", [Validators.required, Validators.email, Validators.maxLength(100)]],
      status: ["Active", Validators.required],
    })
  }

  /**
   * Load all colleges from the API
   */
  loadColleges(): void {
    this.loading = true
    this.collegeService
      .getAllColleges()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (data: College[]) => {
          this.colleges = data
          this.filteredColleges = [...data]
          this.loading = false
          this.showSuccessMessage(`Loaded ${data.length} colleges successfully`)
        },
        error: (error: string) => {
          this.loading = false
          this.showErrorMessage(`Failed to load colleges: ${error}`)
        },
      })
  }

  /**
   * Open form for adding new college
   */
  openAddForm(): void {
    this.isEditMode = false
    this.editingCollegeId = null
    this.collegeForm.reset()
    this.collegeForm.patchValue({ status: "Active" })
    this.showForm = true
  }

  /**
   * Open form for editing existing college
   */
  openEditForm(college: College): void {
    this.isEditMode = true
    this.editingCollegeId = college.id
    this.collegeForm.patchValue({
      clg_name: college.clg_name,
      address: college.address,
      mobile_number: college.mobile_number,
      email: college.email,
      status: college.status,
    })
    this.showForm = true
  }

  /**
   * Cancel form operation
   */
  cancelForm(): void {
    this.showForm = false
    this.isEditMode = false
    this.editingCollegeId = null
    this.collegeForm.reset()
  }

  /**
   * Submit form (save or update)
   */
  onSubmit(): void {
    if (this.collegeForm.valid) {
      const formData: CollegeDTO = this.collegeForm.value

      if (this.isEditMode && this.editingCollegeId) {
        this.updateCollege(this.editingCollegeId, formData)
      } else {
        this.saveCollege(formData)
      }
    } else {
      this.markFormGroupTouched()
      this.showErrorMessage("Please fill all required fields correctly")
    }
  }

  /**
   * Save new college
   */
  private saveCollege(collegeData: CollegeDTO): void {
    this.loading = true
    this.collegeService
      .saveCollege(collegeData)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (newCollege: College) => {
          this.colleges.push(newCollege)
          this.applyFilter()
          this.cancelForm()
          this.loading = false
          this.showSuccessMessage("College saved successfully!")
        },
        error: (error: string) => {
          this.loading = false
          this.showErrorMessage(`Failed to save college: ${error}`)
        },
      })
  }

  /**
   * Update existing college
   */
  private updateCollege(id: number, collegeData: CollegeDTO): void {
    this.loading = true
    this.collegeService
      .updateCollege(id, collegeData)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (updatedCollege: College) => {
          const index = this.colleges.findIndex((c) => c.id === id)
          if (index !== -1) {
            this.colleges[index] = updatedCollege
            this.applyFilter()
          }
          this.cancelForm()
          this.loading = false
          this.showSuccessMessage("College updated successfully!")
        },
        error: (error: string) => {
          this.loading = false
          this.showErrorMessage(`Failed to update college: ${error}`)
        },
      })
  }

  /**
   * Delete college with confirmation
   */
  deleteCollege(college: College): void {
    const confirmDelete = confirm(`Are you sure you want to delete "${college.clg_name}"?`)

    if (confirmDelete) {
      this.loading = true
      this.collegeService
        .deleteCollege(college.id)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: (response) => {
            this.colleges = this.colleges.filter((c) => c.id !== college.id)
            this.applyFilter()
            this.loading = false
            this.showSuccessMessage("College deleted successfully!")
          },
          error: (error: string) => {
            this.loading = false
            this.showErrorMessage(`Failed to delete college: ${error}`)
          },
        })
    }
  }

  /**
   * Apply search filter
   */
  applyFilter(): void {
    if (!this.searchTerm.trim()) {
      this.filteredColleges = [...this.colleges]
    } else {
      const filterValue = this.searchTerm.toLowerCase()
      this.filteredColleges = this.colleges.filter(
        (college) =>
          college.clg_name.toLowerCase().includes(filterValue) ||
          college.address.toLowerCase().includes(filterValue) ||
          college.email.toLowerCase().includes(filterValue) ||
          college.mobile_number.includes(filterValue) ||
          college.status.toLowerCase().includes(filterValue),
      )
    }
  }

  /**
   * Clear search filter
   */
  clearFilter(): void {
    this.searchTerm = ""
    this.applyFilter()
  }

  /**
   * Get form field error message
   */
  getFieldErrorMessage(fieldName: string): string {
    const field = this.collegeForm.get(fieldName)
    if (field?.hasError("required")) {
      return `${this.getFieldDisplayName(fieldName)} is required`
    }
    if (field?.hasError("email")) {
      return "Please enter a valid email address"
    }
    if (field?.hasError("pattern")) {
      return "Please enter a valid 10-digit mobile number"
    }
    if (field?.hasError("minlength")) {
      const minLength = field.errors?.["minlength"]?.requiredLength
      return `${this.getFieldDisplayName(fieldName)} must be at least ${minLength} characters`
    }
    if (field?.hasError("maxlength")) {
      const maxLength = field.errors?.["maxlength"]?.requiredLength
      return `${this.getFieldDisplayName(fieldName)} cannot exceed ${maxLength} characters`
    }
    return ""
  }

  /**
   * Get display name for form fields
   */
  private getFieldDisplayName(fieldName: string): string {
    const displayNames: { [key: string]: string } = {
      clg_name: "College Name",
      address: "Address",
      mobile_number: "Mobile Number",
      email: "Email",
      status: "Status",
    }
    return displayNames[fieldName] || fieldName
  }

  /**
   * Mark all form fields as touched
   */
  private markFormGroupTouched(): void {
    Object.keys(this.collegeForm.controls).forEach((key) => {
      this.collegeForm.get(key)?.markAsTouched()
    })
  }

  /**
   * Show success message
   */
  private showSuccessMessage(message: string): void {
    this.snackBar.open(message, "Close", {
      duration: 3000,
      panelClass: ["success-snackbar"],
    })
  }

  /**
   * Show error message
   */
  private showErrorMessage(message: string): void {
    this.snackBar.open(message, "Close", {
      duration: 5000,
      panelClass: ["error-snackbar"],
    })
  }

  /**
   * Check if field has error and is touched
   */
  isFieldInvalid(fieldName: string): boolean {
    const field = this.collegeForm.get(fieldName)
    return !!(field && field.invalid && field.touched)
  }

  /**
   * Get status badge class
   */
  getStatusClass(status: string): string {
    return status === "Active" ? "status-active" : "status-inactive"
  }

  /**
   * Handle right-click on table row
   */
  onRightClick(event: MouseEvent, college: College): void {
    event.preventDefault()
    event.stopPropagation()

    this.selectedCollege = college
    this.contextMenuPosition = {
      x: event.clientX,
      y: event.clientY,
    }
    this.showContextMenu = true

    // Add click listener to document to close context menu
    document.addEventListener("click", this.onDocumentClick.bind(this), { once: true })
  }

  /**
   * Handle document click to close context menu
   */
  onDocumentClick(): void {
    this.showContextMenu = false
    this.selectedCollege = null
  }

  /**
   * Handle context menu edit action
   */
  onContextMenuEdit(): void {
    if (this.selectedCollege) {
      this.openEditForm(this.selectedCollege)
    }
    this.showContextMenu = false
    this.selectedCollege = null
  }

  /**
   * Handle context menu delete action
   */
  onContextMenuDelete(): void {
    if (this.selectedCollege) {
      this.deleteCollege(this.selectedCollege)
    }
    this.showContextMenu = false
    this.selectedCollege = null
  }

  /**
   * Prevent context menu on other elements
   */
  onTableContextMenu(event: MouseEvent): void {
    if ((event.target as HTMLElement).closest("tr[mat-row]")) {
      return // Allow context menu on table rows
    }
    event.preventDefault() // Prevent context menu on other table elements
  }
}

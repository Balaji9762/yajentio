import { Component, type OnInit, type OnDestroy } from '@angular/core';
import {  FormBuilder,  FormGroup, Validators } from "@angular/forms"
import  { MatSnackBar } from "@angular/material/snack-bar"
import { Subject, takeUntil } from "rxjs"
import { Student, StudentDTO } from './student';
import { StudentService } from './student.service';
@Component({
  selector: 'app-studentinfo',
  standalone: false,
  templateUrl: './studentinfo.component.html',
  styleUrl: './studentinfo.component.css'
})
export class StudentinfoComponent
implements OnInit, OnDestroy {
  // Component properties
  students: Student[] = []
  filteredStudents: Student[] = []
  loading = false
  showForm = false
  isEditMode = false
  editingStudentId: number | null = null
  searchTerm = ""
  selectedFile: File | null = null

  // Form
  studentForm!: FormGroup

  // Table columns
  displayedColumns: string[] = [
    "id",
    "name",
    "email",
    "phone",
    "collegename",
    "personalcourse",
    "kycdocument",
    "actions",
  ]

  // Subscription management
  private destroy$ = new Subject<void>()

  // Context menu properties
  showContextMenu = false
  contextMenuPosition = { x: 0, y: 0 }
  selectedStudent: Student | null = null

  constructor(
    private studentService: StudentService,
    private formBuilder: FormBuilder,
    private snackBar: MatSnackBar,
  ) {
    this.initializeForm()
  }

  ngOnInit(): void {
    this.loadStudents()
  }

  ngOnDestroy(): void {
    this.destroy$.next()
    this.destroy$.complete()
  }

  /**
   * Initialize the reactive form
   */
  private initializeForm(): void {
    this.studentForm = this.formBuilder.group({
      name: ["", [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
      address: ["", [Validators.required, Validators.minLength(5), Validators.maxLength(200)]],
      phone: ["", [Validators.required, Validators.pattern(/^\d{10}$/)]],
      email: ["", [Validators.required, Validators.email, Validators.maxLength(100)]],
      personalcourse: ["", [Validators.required, Validators.maxLength(100)]],
      projectinfo: ["", [Validators.required, Validators.maxLength(500)]],
      collegename: ["", [Validators.required, Validators.maxLength(100)]],
      file: [null, this.isEditMode ? [] : [Validators.required]],
    })
  }

  /**
   * Load all students from the API
   */
  loadStudents(): void {
    this.loading = true
    this.studentService
      .getAllStudents()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (data: Student[]) => {
          this.students = data
          this.filteredStudents = [...data]
          this.loading = false
          this.showSuccessMessage(`Loaded ${data.length} students successfully`)
        },
        error: (error: string) => {
          this.loading = false
          this.showErrorMessage(`Failed to load students: ${error}`)
        },
      })
  }

  /**
   * Open form for adding new student
   */
  openAddForm(): void {
    this.isEditMode = false
    this.editingStudentId = null
    this.selectedFile = null
    this.studentForm.reset()
    this.studentForm.get("file")?.setValidators([Validators.required])
    this.studentForm.get("file")?.updateValueAndValidity()
    this.showForm = true
  }

  /**
   * Open form for editing existing student
   */
  openEditForm(student: Student): void {
    this.isEditMode = true
    this.editingStudentId = student.id
    this.selectedFile = null
    this.studentForm.patchValue({
      name: student.name,
      address: student.address,
      phone: student.phone,
      email: student.email,
      personalcourse: student.personalcourse,
      projectinfo: student.projectinfo,
      collegename: student.collegename,
    })
    this.studentForm.get("file")?.clearValidators()
    this.studentForm.get("file")?.updateValueAndValidity()
    this.showForm = true
  }

  /**
   * Cancel form operation
   */
  cancelForm(): void {
    this.showForm = false
    this.isEditMode = false
    this.editingStudentId = null
    this.selectedFile = null
    this.studentForm.reset()
  }

  /**
   * Handle file selection
   */
  onFileSelected(event: any): void {
    const file = event.target.files[0]
    if (file) {
      this.selectedFile = file
      this.studentForm.patchValue({ file: file })
    }
  }

  /**
   * Submit form (save or update)
   */
  onSubmit(): void {
    if (this.studentForm.valid && (this.selectedFile || this.isEditMode)) {
      const formData: StudentDTO = {
        name: this.studentForm.value.name,
        address: this.studentForm.value.address,
        phone: this.studentForm.value.phone,
        email: this.studentForm.value.email,
        personalcourse: this.studentForm.value.personalcourse,
        projectinfo: this.studentForm.value.projectinfo,
        collegename: this.studentForm.value.collegename,
      }

      if (this.isEditMode && this.editingStudentId) {
        this.updateStudent(this.editingStudentId, formData)
      } else if (this.selectedFile) {
        this.saveStudent(formData, this.selectedFile)
      }
    } else {
      this.markFormGroupTouched()
      this.showErrorMessage("Please fill all required fields correctly and select a file")
    }
  }

  /**
   * Save new student
   */
  private saveStudent(studentData: StudentDTO, file: File): void {
    this.loading = true
    this.studentService
      .saveStudent(studentData, file)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          this.loadStudents() // Reload to get updated data
          this.cancelForm()
          this.loading = false
          this.showSuccessMessage("Student saved successfully!")
        },
        error: (error: string) => {
          this.loading = false
          this.showErrorMessage(`Failed to save student: ${error}`)
        },
      })
  }

  /**
   * Update existing student
   */
  private updateStudent(id: number, studentData: StudentDTO): void {
    this.loading = true
    this.studentService
      .updateStudent(id, studentData, this.selectedFile || undefined)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          this.loadStudents() // Reload to get updated data
          this.cancelForm()
          this.loading = false
          this.showSuccessMessage("Student updated successfully!")
        },
        error: (error: string) => {
          this.loading = false
          this.showErrorMessage(`Failed to update student: ${error}`)
        },
      })
  }

  /**
   * Delete student with confirmation
   */
  deleteStudent(student: Student): void {
    const confirmDelete = confirm(`Are you sure you want to delete "${student.name}"?`)

    if (confirmDelete) {
      this.loading = true
      this.studentService
        .deleteStudent(student.id)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: (response) => {
            this.students = this.students.filter((s) => s.id !== student.id)
            this.applyFilter()
            this.loading = false
            this.showSuccessMessage("Student deleted successfully!")
          },
          error: (error: string) => {
            this.loading = false
            this.showErrorMessage(`Failed to delete student: ${error}`)
          },
        })
    }
  }

  /**
   * Download student file
   */
  downloadFile(student: Student): void {
    if (!student.kycdocument) {
      this.showErrorMessage("No file available for download")
      return
    }

    this.studentService
      .downloadStudentFile(student.id)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (blob: Blob) => {
          const url = window.URL.createObjectURL(blob)
          const link = document.createElement("a")
          link.href = url
          link.download = student.kycdocument
          link.click()
          window.URL.revokeObjectURL(url)
          this.showSuccessMessage("File downloaded successfully!")
        },
        error: (error: string) => {
          this.showErrorMessage(`Failed to download file: ${error}`)
        },
      })
  }

  /**
   * Apply search filter
   */
  applyFilter(): void {
    if (!this.searchTerm.trim()) {
      this.filteredStudents = [...this.students]
    } else {
      const filterValue = this.searchTerm.toLowerCase()
      this.filteredStudents = this.students.filter(
        (student) =>
          (student.name && student.name.toLowerCase().includes(filterValue)) ||
          (student.email && student.email.toLowerCase().includes(filterValue)) ||
          (student.phone && student.phone.includes(filterValue)) ||
          (student.collegename && student.collegename.toLowerCase().includes(filterValue)) ||
          (student.personalcourse && student.personalcourse.toLowerCase().includes(filterValue)),
      )
    }
  }

  /**
   * Clear search filter
   */
  clearFilter(): void {
    this.searchTerm = ""
    this.applyFilter()
  }

  /**
   * Get form field error message
   */
  getFieldErrorMessage(fieldName: string): string {
    const field = this.studentForm.get(fieldName)
    if (field?.hasError("required")) {
      return `${this.getFieldDisplayName(fieldName)} is required`
    }
    if (field?.hasError("email")) {
      return "Please enter a valid email address"
    }
    if (field?.hasError("pattern")) {
      return "Please enter a valid 10-digit phone number"
    }
    if (field?.hasError("minlength")) {
      const minLength = field.errors?.["minlength"]?.requiredLength
      return `${this.getFieldDisplayName(fieldName)} must be at least ${minLength} characters`
    }
    if (field?.hasError("maxlength")) {
      const maxLength = field.errors?.["maxlength"]?.requiredLength
      return `${this.getFieldDisplayName(fieldName)} cannot exceed ${maxLength} characters`
    }
    return ""
  }

  /**
   * Get display name for form fields
   */
  private getFieldDisplayName(fieldName: string): string {
    const displayNames: { [key: string]: string } = {
      name: "Name",
      address: "Address",
      phone: "Phone",
      email: "Email",
      personalcourse: "Personal Course",
      projectinfo: "Project Info",
      collegename: "College Name",
      file: "File",
    }
    return displayNames[fieldName] || fieldName
  }

  /**
   * Mark all form fields as touched
   */
  private markFormGroupTouched(): void {
    Object.keys(this.studentForm.controls).forEach((key) => {
      this.studentForm.get(key)?.markAsTouched()
    })
  }

  /**
   * Show success message
   */
  private showSuccessMessage(message: string): void {
    this.snackBar.open(message, "Close", {
      duration: 3000,
      panelClass: ["success-snackbar"],
    })
  }

  /**
   * Show error message
   */
  private showErrorMessage(message: string): void {
    this.snackBar.open(message, "Close", {
      duration: 5000,
      panelClass: ["error-snackbar"],
    })
  }

  /**
   * Check if field has error and is touched
   */
  isFieldInvalid(fieldName: string): boolean {
    const field = this.studentForm.get(fieldName)
    return !!(field && field.invalid && field.touched)
  }

  /**
   * Handle right-click on table row
   */
  onRightClick(event: MouseEvent, student: Student): void {
    event.preventDefault()
    event.stopPropagation()

    this.selectedStudent = student
    this.contextMenuPosition = {
      x: event.clientX,
      y: event.clientY,
    }
    this.showContextMenu = true

    // Add click listener to document to close context menu
    document.addEventListener("click", this.onDocumentClick.bind(this), { once: true })
  }

  /**
   * Handle document click to close context menu
   */
  onDocumentClick(): void {
    this.showContextMenu = false
    this.selectedStudent = null
  }

  /**
   * Handle context menu edit action
   */
  onContextMenuEdit(): void {
    if (this.selectedStudent) {
      this.openEditForm(this.selectedStudent)
    }
    this.showContextMenu = false
    this.selectedStudent = null
  }

  /**
   * Handle context menu delete action
   */
  onContextMenuDelete(): void {
    if (this.selectedStudent) {
      this.deleteStudent(this.selectedStudent)
    }
    this.showContextMenu = false
    this.selectedStudent = null
  }

  /**
   * Handle context menu download action
   */
  onContextMenuDownload(): void {
    if (this.selectedStudent) {
      this.downloadFile(this.selectedStudent)
    }
    this.showContextMenu = false
    this.selectedStudent = null
  }

  /**
   * Prevent context menu on other elements
   */
  onTableContextMenu(event: MouseEvent): void {
    if ((event.target as HTMLElement).closest("tr[mat-row]")) {
      return // Allow context menu on table rows
    }
    event.preventDefault() // Prevent context menu on other table elements
  }
}

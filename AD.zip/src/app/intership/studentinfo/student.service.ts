import { Injectable } from '@angular/core';
import  { HttpClient, HttpErrorResponse } from "@angular/common/http"
import { type Observable, throwError } from "rxjs"
import { catchError } from "rxjs/operators"
//import type { Student, StudentDTO, StudentUploadResponse } from "../models/student.model"
import { Student, StudentDTO, StudentUploadResponse } from './student';
@Injectable({
  providedIn: 'root'
})
export class StudentService {

   private readonly API_BASE_URL = "http://3.108.126.170:8080"

  constructor(private http: HttpClient) {}

  /**
   * Get all students from the API
   */
  getAllStudents(): Observable<Student[]> {
    return this.http.get<Student[]>(`${this.API_BASE_URL}/getAllStudentinfo`).pipe(catchError(this.handleError))
  }

  /**
   * Save a new student with file upload
   */
  saveStudent(student: StudentDTO, file: File): Observable<StudentUploadResponse> {
    const formData = new FormData()
    formData.append("Studentinfo", JSON.stringify(student))
    formData.append("Studentinfofileupload", file)

    return this.http
      .post<StudentUploadResponse>(`${this.API_BASE_URL}/Studentinfoupload`, formData)
      .pipe(catchError(this.handleError))
  }

  /**
   * Update an existing student
   */
  updateStudent(id: number, student: StudentDTO, file?: File): Observable<any> {
    const formData = new FormData()
    formData.append("Studentinfo", JSON.stringify(student))

    if (file) {
      formData.append("Studentinfofileupload", file)
    }

    return this.http
      .put(`${this.API_BASE_URL}/updatedStudentinfo/${id}`, formData, { responseType: 'text' })
      .pipe(catchError(this.handleError))
  }

  /**
   * Delete a student by ID
   */
  deleteStudent(id: number): Observable<any> {
    return this.http.delete(`${this.API_BASE_URL}/deleteStudentinfo/${id}`, { responseType: 'text' }).pipe(catchError(this.handleError))
  }

  /**
   * Download student file
   */
  downloadStudentFile(id: number): Observable<Blob> {
    return this.http
      .get(`${this.API_BASE_URL}/downloadStudentinfo/${id}`, {
        responseType: "blob",
      })
      .pipe(catchError(this.handleError))
  }

  /**
   * Get download URL for student file
   */
  getDownloadUrl(id: number): string {
    return `${this.API_BASE_URL}/downloadStudentinfo/${id}`
  }

  /**
   * Handle HTTP errors
   */
  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = "An unknown error occurred!"

    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Client Error: ${error.error.message}`
    } else {
      // Server-side error
      errorMessage = `Server Error: ${error.status} - ${error.message}`

      // Handle specific HTTP status codes
      switch (error.status) {
        case 404:
          errorMessage = "Student not found"
          break
        case 500:
          errorMessage = "Internal server error"
          break
        case 0:
          errorMessage = "Unable to connect to server"
          break
      }
    }

    console.error("Student Service Error:", error)
    return throwError(() => errorMessage)
  }
}

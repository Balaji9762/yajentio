export interface Student {
 id: number
  name: string
  address: string
  phone: string
  email: string
  personalcourse: string
  projectinfo: string
  collegename: string
  kycdocument: string
  filedata: string // Base64 encoded file data
  downloadurl: string
}

export interface StudentDTO {
  name: string
  address: string
  phone: string
  email: string
  personalcourse: string
  projectinfo: string
  collegename: string
}

export interface StudentUploadResponse {
  Studentinfo_id: number
  downloadUrl: string
  message: string
}

export interface ApiResponse<T> {
  data?: T
  message?: string
  success: boolean
}

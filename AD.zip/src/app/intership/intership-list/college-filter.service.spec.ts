import { TestBed } from '@angular/core/testing';

import { CollegeFilterService } from './college-filter.service';

describe('CollegeFilterService', () => {
  let service: CollegeFilterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CollegeFilterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { Injectable } from '@angular/core';
import  { HttpClient, HttpErrorResponse } from "@angular/common/http"
import { type Observable, throwError } from "rxjs"
import { catchError } from "rxjs/operators"
//import  { CollegeFilterRequest, CollegeStudent } from "../models/college-filter.model"
import { CollegeFilterRequest, CollegeStudent } from './college-filter';
//import  { StudentDTO } from "../models/student.model"
import { StudentDTO } from '../studentinfo/student';
@Injectable({
  providedIn: 'root'
})
export class CollegeFilterService {

   private readonly API_BASE_URL = "http://3.108.126.170:8080"

  constructor(private http: HttpClient) {}

  /**
   * Get all college names
   */
  getAllCollegeNames(): Observable<string[]> {
    return this.http.get<string[]>(`${this.API_BASE_URL}/collegename`).pipe(catchError(this.handleError))
  }

  /**
   * Get students by college name using GET method
   */
  getStudentsByCollegeNameGet(collegename: string): Observable<CollegeStudent[]> {
    const encodedCollegeName = encodeURIComponent(collegename)
    return this.http
      .get<CollegeStudent[]>(`${this.API_BASE_URL}/bycollege?collegename=${encodedCollegeName}`)
      .pipe(catchError(this.handleError))
  }

  /**
   * Get students by college name using POST method
   */
  getStudentsByCollegeNamePost(request: CollegeFilterRequest): Observable<CollegeStudent[]> {
    return this.http
      .post<CollegeStudent[]>(`${this.API_BASE_URL}/bycollegename`, request)
      .pipe(catchError(this.handleError))
  }

  /**
   * Update student
   */
  updateStudent(id: number, student: StudentDTO, file?: File): Observable<string> {
    const formData = new FormData()
    formData.append("Studentinfo", JSON.stringify(student))

    if (file) {
      formData.append("Studentinfofileupload", file)
    }

    return this.http
      .put<string>(`${this.API_BASE_URL}/updatedStudentinfo/${id}`, formData)
      .pipe(catchError(this.handleError))
  }

  /**
   * Delete student
   */
  deleteStudent(id: number): Observable<string> {
    return this.http.delete<string>(`${this.API_BASE_URL}/deleteStudentinfo/${id}`).pipe(catchError(this.handleError))
  }

  /**
   * Download student file
   */
  downloadStudentFile(id: number): Observable<Blob> {
    return this.http
      .get(`${this.API_BASE_URL}/downloadStudentinfo/${id}`, {
        responseType: "blob",
      })
      .pipe(catchError(this.handleError))
  }

  /**
   * Handle HTTP errors
   */
  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = "An unknown error occurred!"

    if (error.error instanceof ErrorEvent) {
      errorMessage = `Client Error: ${error.error.message}`
    } else {
      errorMessage = `Server Error: ${error.status} - ${error.message}`

      switch (error.status) {
        case 404:
          errorMessage = "Data not found"
          break
        case 500:
          errorMessage = "Internal server error"
          break
        case 0:
          errorMessage = "Unable to connect to server"
          break
      }
    }

    console.error("College Filter Service Error:", error)
    return throwError(() => errorMessage)
  }
}

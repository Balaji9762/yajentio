import { Component, type OnInit, type OnDestroy  } from '@angular/core';
import {  FormBuilder,  FormGroup, Validators } from "@angular/forms"
import  { MatSnackBar } from "@angular/material/snack-bar"
import { Subject, takeUntil } from "rxjs"
//import type { CollegeStudent, CollegeFilterRequest } from "../models/college-filter.model"
import { CollegeStudent, CollegeFilterRequest } from './college-filter';
//import type { StudentDTO } from "../models/student.model"
import { StudentDTO } from '../studentinfo/student';
//import type { CollegeFilterService } from "../services/college-filter.service"
import { CollegeFilterService } from './college-filter.service';
@Component({
  selector: 'app-intership-list',
  standalone: false,
  templateUrl: './intership-list.component.html',
  styleUrl: './intership-list.component.css'
})
export class IntershipListComponent
implements OnInit, OnDestroy {
  // Component properties
  collegeNames: string[] = []
  students: CollegeStudent[] = []
  filteredStudents: CollegeStudent[] = []
  selectedCollegeName = ""
  loading = false
  showEditForm = false
  editingStudent: CollegeStudent | null = null
  selectedFile: File | null = null
  searchTerm = ""

  // Form
  editForm!: FormGroup
  collegeFilterForm!: FormGroup

  // Table columns
  displayedColumns: string[] = [
    "id",
    "name",
    "email",
    "phone",
    "address",
    "personalcourse",
    "projectinfo",
    "kycdocument",
    "actions",
  ]

  // Subscription management
  private destroy$ = new Subject<void>()

  // Context menu properties
  showContextMenu = false
  contextMenuPosition = { x: 0, y: 0 }
  selectedStudent: CollegeStudent | null = null

  constructor(
    private collegeFilterService: CollegeFilterService,
    private formBuilder: FormBuilder,
    private snackBar: MatSnackBar,
  ) {
    this.initializeForms()
  }

  ngOnInit(): void {
    console.log('IntershipListComponent initialized')
    this.loadCollegeNames()
  }

  ngOnDestroy(): void {
    this.destroy$.next()
    this.destroy$.complete()
  }

  /**
   * Initialize forms
   */
  private initializeForms(): void {
    this.collegeFilterForm = this.formBuilder.group({
      collegename: ["", Validators.required],
    })

    this.editForm = this.formBuilder.group({
      name: ["", [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
      address: ["", [Validators.required, Validators.minLength(5), Validators.maxLength(200)]],
      phone: ["", [Validators.required, Validators.pattern(/^\d{10}$/)]],
      email: ["", [Validators.required, Validators.email, Validators.maxLength(100)]],
      personalcourse: ["", [Validators.required, Validators.maxLength(100)]],
      projectinfo: ["", [Validators.required, Validators.maxLength(500)]],
      collegename: ["", [Validators.required, Validators.maxLength(100)]],
      file: [null],
    })
  }

  /**
   * Load all college names
   */
  loadCollegeNames(): void {
    this.loading = true
    this.collegeFilterService
      .getAllCollegeNames()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (names: string[]) => {
          this.collegeNames = names
          this.loading = false
          this.showSuccessMessage(`Loaded ${names.length} college names`)
        },
        error: (error: string) => {
          this.loading = false
          this.showErrorMessage(`Failed to load college names: ${error}`)
        },
      })
  }

  /**
   * Filter students by college name
   */
  filterByCollege(): void {
    if (this.collegeFilterForm.valid) {
      const collegeName = this.collegeFilterForm.value.collegename
      this.selectedCollegeName = collegeName
      this.loading = true

      // Using POST method as shown in the API example
      const request: CollegeFilterRequest = { collegename: collegeName }

      this.collegeFilterService
        .getStudentsByCollegeNamePost(request)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: (students: CollegeStudent[]) => {
            this.students = students
            this.filteredStudents = [...students]
            this.loading = false
            this.showSuccessMessage(`Found ${students.length} students from ${collegeName}`)
          },
          error: (error: string) => {
            this.loading = false
            this.showErrorMessage(`Failed to load students: ${error}`)
          },
        })
    }
  }

  /**
   * Clear filter and reset
   */
  clearFilter(): void {
    this.collegeFilterForm.reset()
    this.selectedCollegeName = ""
    this.students = []
    this.filteredStudents = []
    this.searchTerm = ""
  }

  /**
   * Apply search filter
   */
  applySearchFilter(): void {
    if (!this.searchTerm.trim()) {
      this.filteredStudents = [...this.students]
    } else {
      const filterValue = this.searchTerm.toLowerCase()
      this.filteredStudents = this.students.filter(
        (student) =>
          student.name.toLowerCase().includes(filterValue) ||
          student.email.toLowerCase().includes(filterValue) ||
          student.phone.includes(filterValue) ||
          student.personalcourse.toLowerCase().includes(filterValue) ||
          student.projectinfo.toLowerCase().includes(filterValue),
      )
    }
  }

  /**
   * Clear search
   */
  clearSearch(): void {
    this.searchTerm = ""
    this.applySearchFilter()
  }

  /**
   * Open edit form
   */
  openEditForm(student: CollegeStudent): void {
    this.editingStudent = student
    this.selectedFile = null
    this.editForm.patchValue({
      name: student.name,
      address: student.address,
      phone: student.phone,
      email: student.email,
      personalcourse: student.personalcourse,
      projectinfo: student.projectinfo,
      collegename: student.collegename,
    })
    this.showEditForm = true
  }

  /**
   * Cancel edit
   */
  cancelEdit(): void {
    this.showEditForm = false
    this.editingStudent = null
    this.selectedFile = null
    this.editForm.reset()
  }

  /**
   * Handle file selection
   */
  onFileSelected(event: any): void {
    const file = event.target.files[0]
    if (file) {
      this.selectedFile = file
      this.editForm.patchValue({ file: file })
    }
  }

  /**
   * Update student
   */
  updateStudent(): void {
    if (this.editForm.valid && this.editingStudent) {
      const formData: StudentDTO = {
        name: this.editForm.value.name,
        address: this.editForm.value.address,
        phone: this.editForm.value.phone,
        email: this.editForm.value.email,
        personalcourse: this.editForm.value.personalcourse,
        projectinfo: this.editForm.value.projectinfo,
        collegename: this.editForm.value.collegename,
      }

      this.loading = true
      this.collegeFilterService
        .updateStudent(this.editingStudent.id, formData, this.selectedFile || undefined)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: (response) => {
            // Refresh the student list
            this.filterByCollege()
            this.cancelEdit()
            this.loading = false
            this.showSuccessMessage("Student updated successfully!")
          },
          error: (error: string) => {
            this.loading = false
            this.showErrorMessage(`Failed to update student: ${error}`)
          },
        })
    } else {
      this.markFormGroupTouched()
      this.showErrorMessage("Please fill all required fields correctly")
    }
  }

  /**
   * Delete student
   */
  deleteStudent(student: CollegeStudent): void {
    const confirmDelete = confirm(`Are you sure you want to delete "${student.name}"?`)

    if (confirmDelete) {
      this.loading = true
      this.collegeFilterService
        .deleteStudent(student.id)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: (response) => {
            this.students = this.students.filter((s) => s.id !== student.id)
            this.applySearchFilter()
            this.loading = false
            this.showSuccessMessage("Student deleted successfully!")
          },
          error: (error: string) => {
            this.loading = false
            this.showErrorMessage(`Failed to delete student: ${error}`)
          },
        })
    }
  }

  /**
   * Download student file
   */
  downloadFile(student: CollegeStudent): void {
    if (!student.kycdocument) {
      this.showErrorMessage("No file available for download")
      return
    }

    this.collegeFilterService
      .downloadStudentFile(student.id)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (blob: Blob) => {
          const url = window.URL.createObjectURL(blob)
          const link = document.createElement("a")
          link.href = url
          link.download = student.kycdocument
          link.click()
          window.URL.revokeObjectURL(url)
          this.showSuccessMessage("File downloaded successfully!")
        },
        error: (error: string) => {
          this.showErrorMessage(`Failed to download file: ${error}`)
        },
      })
  }

  /**
   * Handle right-click on table row
   */
  onRightClick(event: MouseEvent, student: CollegeStudent): void {
    event.preventDefault()
    event.stopPropagation()

    this.selectedStudent = student
    this.contextMenuPosition = {
      x: event.clientX,
      y: event.clientY,
    }
    this.showContextMenu = true

    document.addEventListener("click", this.onDocumentClick.bind(this), { once: true })
  }

  /**
   * Handle document click to close context menu
   */
  onDocumentClick(): void {
    this.showContextMenu = false
    this.selectedStudent = null
  }

  /**
   * Context menu actions
   */
  onContextMenuEdit(): void {
    if (this.selectedStudent) {
      this.openEditForm(this.selectedStudent)
    }
    this.showContextMenu = false
    this.selectedStudent = null
  }

  onContextMenuDelete(): void {
    if (this.selectedStudent) {
      this.deleteStudent(this.selectedStudent)
    }
    this.showContextMenu = false
    this.selectedStudent = null
  }

  onContextMenuDownload(): void {
    if (this.selectedStudent) {
      this.downloadFile(this.selectedStudent)
    }
    this.showContextMenu = false
    this.selectedStudent = null
  }

  /**
   * Prevent context menu on other elements
   */
  onTableContextMenu(event: MouseEvent): void {
    if ((event.target as HTMLElement).closest("tr[mat-row]")) {
      return
    }
    event.preventDefault()
  }

  /**
   * Get form field error message
   */
  getFieldErrorMessage(fieldName: string): string {
    const field = this.editForm.get(fieldName)
    if (field?.hasError("required")) {
      return `${this.getFieldDisplayName(fieldName)} is required`
    }
    if (field?.hasError("email")) {
      return "Please enter a valid email address"
    }
    if (field?.hasError("pattern")) {
      return "Please enter a valid 10-digit phone number"
    }
    if (field?.hasError("minlength")) {
      const minLength = field.errors?.["minlength"]?.requiredLength
      return `${this.getFieldDisplayName(fieldName)} must be at least ${minLength} characters`
    }
    if (field?.hasError("maxlength")) {
      const maxLength = field.errors?.["maxlength"]?.requiredLength
      return `${this.getFieldDisplayName(fieldName)} cannot exceed ${maxLength} characters`
    }
    return ""
  }

  /**
   * Get display name for form fields
   */
  private getFieldDisplayName(fieldName: string): string {
    const displayNames: { [key: string]: string } = {
      name: "Name",
      address: "Address",
      phone: "Phone",
      email: "Email",
      personalcourse: "Personal Course",
      projectinfo: "Project Info",
      collegename: "College Name",
      file: "File",
    }
    return displayNames[fieldName] || fieldName
  }

  /**
   * Mark all form fields as touched
   */
  private markFormGroupTouched(): void {
    Object.keys(this.editForm.controls).forEach((key) => {
      this.editForm.get(key)?.markAsTouched()
    })
  }

  /**
   * Show success message
   */
  private showSuccessMessage(message: string): void {
    this.snackBar.open(message, "Close", {
      duration: 3000,
      panelClass: ["success-snackbar"],
    })
  }

  /**
   * Show error message
   */
  private showErrorMessage(message: string): void {
    this.snackBar.open(message, "Close", {
      duration: 5000,
      panelClass: ["error-snackbar"],
    })
  }

  /**
   * Check if field has error and is touched
   */
  isFieldInvalid(fieldName: string): boolean {
    const field = this.editForm.get(fieldName)
    return !!(field && field.invalid && field.touched)
  }

}

export interface CollegeFilter {
 collegename: string
}

// Alias for backward compatibility
export interface CollegeFilterRequest {
 collegename: string
}

export interface CollegeStudent {
  id: number
  name: string
  address: string
  phone: string
  email: string
  personalcourse: string
  projectinfo: string
  collegename: string
  kycdocument: string
  filedata: string
  downloadurl?: string
}


import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http"
import { Observable } from "rxjs"



@Injectable({
  providedIn: 'root'
})
export class BlogService {
   private apiUrl = 'http://3.108.126.170:8080/sign_up';

  constructor(private http: HttpClient) {}

  registerUser(userData: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, userData);
  }
}

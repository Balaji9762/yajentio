import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms"

import { BlogService } from './blog.service';
@Component({
  selector: 'app-blog',
  standalone: false,
  templateUrl: './blog.component.html',
  styleUrl: './blog.component.css'
})
export class BlogComponent  {
signupForm: FormGroup;
  responseMessage: string = '';
  isError: boolean = false;

  constructor(private fb: FormBuilder, private blogService: BlogService) {
    this.signupForm = this.fb.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.signupForm.valid) {
      this.blogService.registerUser(this.signupForm.value).subscribe({
        next: (res) => {
          this.isError = !res.status;
          this.responseMessage = res.message;
        },
        error: (err) => {
          this.isError = true;
          this.responseMessage = 'An error occurred while registering.';
        }
      });
    }
  }

}

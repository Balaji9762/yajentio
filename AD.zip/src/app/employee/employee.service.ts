import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface Employee {
  id?: number;
  name: string;
  designation: string;
  location: string;
  status: string;
  filename?: string;
  filedata?: any;
  downloadUrl?: string;
}

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
//private apiUrl = 'http://3.108.126.170:8080';
private apiUrl = environment.apiUrl;
  constructor(private http: HttpClient) {}

  getAll(): Observable<Employee[]> {
    return this.http.get<Employee[]>(`${this.apiUrl}/getAllEmployee`);
  }

  add(formData: FormData): Observable<any> {
    return this.http.post(`${this.apiUrl}/uploadEmployee`, formData);
  }

  update(id: number, formData: FormData): Observable<any> {
    return this.http.put(`${this.apiUrl}/updateEmployee/${id}`, formData);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/deleteEmployee/${id}`);
  }

  download(id: number): string {
    return `${this.apiUrl}/downloadEmployee/${id}`;
  }
}

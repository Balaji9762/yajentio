import { Component, OnInit } from '@angular/core';
import {Employee, EmployeeService } from './employee.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { HostListener } from '@angular/core';

@Component({
  selector: 'app-employee',
  standalone: false,
  templateUrl: './employee.component.html',
  styleUrl: './employee.component.css'
})
export class EmployeeComponent implements OnInit {
  employeeForm: FormGroup;
  employees: Employee[] = [];
  selectedFile: File | null = null;
  editingId: number | null = null;

  statusOptions = ['ACTIVE', 'INACTIVE', 'On Leave'];
  constructor(private fb: FormBuilder, private empService: EmployeeService) {
    this.employeeForm = this.fb.group({
      name: [''],
      designation: [''],
      location: [''],
      status: ['']
    });
  }


  ngOnInit(): void {
    this.loadEmployees();
  }

  onFileSelected(event: any): void {
    this.selectedFile = event.target.files[0];
  }

  onSubmit(): void {
    if (this.editingId) {
      // Prepare JSON object
      const updateData = this.employeeForm.value;

      // Call update
      this.empService.update(this.editingId, updateData).subscribe({
        next: () => {
          this.employeeForm.reset();
          this.selectedFile = null;
          this.editingId = null;
          this.loadEmployees();
        },
        error: (error) => {
          console.error('Update failed', error);
        }
      });
    } else {
      // Prepare FormData for add
      const empDetails = JSON.stringify(this.employeeForm.value);
      const formData = new FormData();
      formData.append('EmployeeDetails', empDetails);
      if (this.selectedFile) formData.append('file', this.selectedFile);

      // Call add
      this.empService.add(formData).subscribe({
        next: () => {
          this.employeeForm.reset();
          this.selectedFile = null;
          this.editingId = null;
          this.loadEmployees();
        },
        error: (error) => {
          console.error('Add failed', error);
        }
      });
    }
  }
  loadEmployees(): void {
    this.empService.getAll().subscribe({
      next: (data) => {
        this.employees = data.map(emp => ({
          ...emp,
          downloadUrl: emp.id ? this.empService.download(emp.id) : undefined
        }));
      },
      error: (error) => {
        console.error('Failed to load employees', error);
      }
    });
  }

  contextMenuVisible = false;
  contextMenuPosition = { x: 0, y: 0 };
  contextMenuEmployee: Employee = {} as Employee;

  onRightClick(event: MouseEvent, employee: Employee): void {
    event.preventDefault();
    this.contextMenuVisible = true;
    this.contextMenuPosition = { x: event.clientX, y: event.clientY };
    this.contextMenuEmployee = employee;
  }

  @HostListener('document:click')
  hideContextMenu(): void {
    this.contextMenuVisible = false;
  }

  getRowClass(status: string): string {
    switch (status?.toLowerCase()) {
      case 'active':
        return 'active-row';
      case 'inactive':
        return 'inactive-row';
      case 'pending':
        return 'pending-row';
      case 'blocked':
        return 'blocked-row';
      case 'on leave':
        return 'row-leave';
      default:
        return '';
    }
  }

  getStatusColor(status: string): string {
    // This method can be used with ngStyle in the template
    // Or consider replacing with ngClass for better maintainability
    switch (status?.toLowerCase()) {
      case 'active': return 'green';
      case 'inactive': return 'gray';
      case 'on leave': return 'orange';
      case 'pending': return 'blue';
      case 'blocked': return 'red';
      default: return 'black';
    }
  }

  // Method to highlight rows after operations
  highlightRow(rowElement: HTMLElement): void {
    rowElement.classList.add('highlight-animation');
    setTimeout(() => {
      rowElement.classList.remove('highlight-animation');
    }, 1500);
  }

  editEmployee(employee: Employee): void {
    this.editingId = employee.id || null;
    this.employeeForm.patchValue({
      name: employee.name,
      designation: employee.designation,
      location: employee.location,
      status: employee.status
    });
    this.contextMenuVisible = false;
  }

  deleteEmployee(id: number): void {
    if (confirm('Are you sure you want to delete this employee?')) {
      this.empService.delete(id).subscribe({
        next: () => {
          this.loadEmployees();
          this.contextMenuVisible = false;
        },
        error: (error) => {
          console.error('Delete failed', error);
        }
      });
    }
  }
}

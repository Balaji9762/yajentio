import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { CoursesComponent } from './courses/courses.component';
import { TopicsComponent } from './topics/topics.component';
import { JobsComponent } from './jobs/jobs.component';

import { EmployeeComponent } from './employee/employee.component';
import { PaymentsComponent } from './payments/payments.component';
import { CollectionComponent } from './payments/collection/collection.component';
import { BlogComponent } from './blog/blog.component';
import { PurchaseComponent } from './payments/purchase/purchase.component';
import { PaymentComponent } from './payments/payment/payment.component';
import { ServiceComponent } from './service/service.component';
import { authGuard } from './login/auth.guard';
import { SignupComponent } from './payments/signup/signup.component';

import { CourseDocsComponent } from './course-docs/course-docs.component';
import { CourseDetailsComponent } from './course-details/course-details.component';
import { CreateUserComponent } from './home/create-user/create-user.component';
import { HomeComponent } from './home/home.component';

import { ContactDetailsComponent } from './contact-details/contact-details.component';
import { BranchesComponent } from './home/branches/branches.component';
import { StudentDetailsComponent } from './course-details/student-details/student-details.component';
import { CourseRegistrationComponent } from './course-details/course-registration/course-registration.component';
import { StudentDocComponent } from './course-details/student-doc/student-doc.component';
import { CollegeinfoComponent } from './intership/collegeinfo/collegeinfo.component';
import { StudentinfoComponent } from './intership/studentinfo/studentinfo.component';
import { IntershipComponent } from './intership/intership.component';
import { IntershipListComponent } from './intership/intership-list/intership-list.component';
import { AssignmentComponent } from './assignment/assignment.component';
import { ExamTestComponent } from './assignment/exam-test/exam-test.component';


const routes: Routes = [
  {
    path :"login",
    component:LoginComponent
  },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'blog', component: BlogComponent, canActivate: [authGuard] },
  { path: 'Employee', component: EmployeeComponent, canActivate: [authGuard] },
  { path: 'Service', component: ServiceComponent, canActivate: [authGuard] },
   { path: 'Jobs', component: JobsComponent, canActivate: [authGuard] },
 { path: 'ContactDetails', component: ContactDetailsComponent, canActivate: [authGuard] },

  { path: 'CourseDetails',
    component: CourseDetailsComponent,
    canActivate: [authGuard],
    children:[
       { path: 'Courses',
         component: CoursesComponent
      },
      { path: 'CourseDocs',
        component:CourseDocsComponent,
      },
      { path: 'Topics',
        component: TopicsComponent,
      },
      { path: 'StudentDetails',
        component: StudentDetailsComponent,
      },
      { path: 'CourseRegistration',
        component: CourseRegistrationComponent,
      },
      { path: 'StudentDoc',
        component: StudentDocComponent,
      },


    ]
   },
   { path: 'payments',
    component: PaymentsComponent,
    canActivate: [authGuard],
    children:[
      {
        path:"Payment",
        component:PaymentComponent,
      },
      {
        path:"Collection",
        component:CollectionComponent,
      },
      {
        path:"Purchase",
        component:PurchaseComponent,
      },


    ]
   },
    { path: 'Home',
    component: HomeComponent,
    canActivate: [authGuard],
    children:[
     {
      path:"CreateUser",
      component:CreateUserComponent
     },
      {
      path:"branches",
      component:BranchesComponent
     }

    ]
   },
   { path: 'Internship',
    component: IntershipComponent,
    children:[
     { path: '', redirectTo: 'CollegeInfo', pathMatch: 'full' },
     { path: 'CollegeInfo',
        component: CollegeinfoComponent,
      },
       { path: 'StudentInfo',
        component: StudentinfoComponent,
      },
      { path: 'InternshipList',
        component: IntershipListComponent,
      }
    ]
   },
    { path: 'Assignment', component: AssignmentComponent, canActivate: [authGuard] },
    { path: 'exam/:courseId', component: ExamTestComponent, canActivate: [authGuard] },
    { path: '**', redirectTo: 'login' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{useHash:true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BranchesService } from './branches.service';
import { Branch } from './Branch';
@Component({
  selector: 'app-branches',
  standalone: false,
  templateUrl: './branches.component.html',
  styleUrl: './branches.component.css'
})
export class BranchesComponent implements OnInit {
 branches: Branch[] = []
  branchForm: FormGroup
  editingId: number | null = null
  isLoading = false
  error: string | null = null
  success: string | null = null

  // Context menu properties
  contextMenuVisible = false
  contextMenuPosition = { x: 0, y: 0 }
  contextMenuItem: Branch | null = null

  constructor(
    private branchesService: BranchesService,
    private fb: FormBuilder,
  ) {
    this.branchForm = this.fb.group({
      usr_role: ["", Validators.required],
      branch_name: ["", Validators.required],
      branch_location: ["", Validators.required],
    })
  }

  ngOnInit(): void {
    this.loadBranches()

    // Close context menu when clicking outside
    document.addEventListener("click", () => {
      this.contextMenuVisible = false
    })
  }

  loadBranches(): void {
    this.isLoading = true
    this.branchesService.getBranches().subscribe({
      next: (data) => {
        this.branches = data
        this.isLoading = false
      },
      error: (err) => {
        this.error = "Failed to load branches. Please try again."
        this.isLoading = false
        console.error("Error loading branches:", err)
      },
    })
  }

  onSubmit(): void {
    if (this.branchForm.invalid) {
      this.markFormGroupTouched(this.branchForm)
      return
    }

    this.isLoading = true
    const branchData = this.branchForm.value

    if (this.editingId) {
      // Update existing branch
      this.branchesService.updateBranch(this.editingId, branchData).subscribe({
        next: (updatedBranch) => {
          this.success = "Branch updated successfully!"
          this.loadBranches()
          this.resetForm()
          this.isLoading = false
        },
        error: (err) => {
          this.error = "Failed to update branch. Please try again."
          this.isLoading = false
          console.error("Error updating branch:", err)
        },
      })
    } else {
      // Create new branch
      this.branchesService.createBranch(branchData).subscribe({
        next: (newBranch) => {
          this.success = "Branch created successfully!"
          this.loadBranches()
          this.resetForm()
          this.isLoading = false
        },
        error: (err) => {
          this.error = "Failed to create branch. Please try again."
          this.isLoading = false
          console.error("Error creating branch:", err)
        },
      })
    }
  }

  onRightClick(event: MouseEvent, branch: Branch): void {
    event.preventDefault()
    this.contextMenuVisible = true
    this.contextMenuPosition = { x: event.clientX, y: event.clientY }
    this.contextMenuItem = branch
  }

  edit(branch: Branch): void {
    this.editingId = branch.usr_id
    this.branchForm.patchValue({
      usr_role: branch.usr_role,
      branch_name: branch.branch_name,
      branch_location: branch.branch_location,
    })
    this.contextMenuVisible = false

    // Scroll to form
    const formElement = document.querySelector("form")
    if (formElement) {
      formElement.scrollIntoView({ behavior: "smooth", block: "start" })
    }
  }

  delete(id: number): void {
    if (confirm("Are you sure you want to delete this branch?")) {
      this.isLoading = true
      this.branchesService.deleteBranch(id).subscribe({
        next: (response) => {
          this.success = "Branch deleted successfully!"
          this.loadBranches()
          this.isLoading = false
          this.contextMenuVisible = false
        },
        error: (err) => {
          this.error = "Failed to delete branch. Please try again."
          this.isLoading = false
          console.error("Error deleting branch:", err)
        },
      })
    } else {
      this.contextMenuVisible = false
    }
  }

  resetForm(): void {
    this.branchForm.reset()
    this.editingId = null
  }

  clearMessages(): void {
    this.error = null
    this.success = null
  }

  // Helper method to mark all form controls as touched
  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((key) => {
      const control = formGroup.get(key)
      control?.markAsTouched()
    })
  }
}

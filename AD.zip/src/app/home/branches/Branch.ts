export interface Branch {
   usr_id: number
  usr_role: string
  branch_name: string
  branch_location: string
}

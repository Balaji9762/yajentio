import { Injectable } from '@angular/core';
import  { HttpClient, HttpErrorResponse } from "@angular/common/http"
import { type Observable, throwError } from "rxjs"
import { catchError } from "rxjs/operators"
import { Branch } from './Branch';
@Injectable({
  providedIn: 'root'
})
export class BranchesService {

   private apiUrl = "http://3.108.126.170:8080"

  constructor(private http: HttpClient) {}

  getBranches(): Observable<Branch[]> {
    return this.http.get<Branch[]>(`${this.apiUrl}/getbranches`).pipe(catchError(this.handleError))
  }

  createBranch(branch: Branch): Observable<Branch> {
    return this.http.post<Branch>(`${this.apiUrl}/savebranches`, branch).pipe(catchError(this.handleError))
  }

  updateBranch(id: number, branch: Branch): Observable<Branch> {
    return this.http.put<Branch>(`${this.apiUrl}/updatedbranches/${id}`, branch).pipe(catchError(this.handleError))
  }

  deleteBranch(id: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/deletebranches/${id}`).pipe(catchError(this.handleError))
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = "An unknown error occurred!"
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Error: ${error.error.message}`
    } else {
      // Server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`
    }
    console.error(errorMessage)
    return throwError(() => new Error(errorMessage))
  }


}

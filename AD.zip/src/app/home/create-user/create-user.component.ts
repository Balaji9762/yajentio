import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms"

import { CreateUserService } from './create-user.service';
@Component({
  selector: 'app-create-user',
  standalone: false,
  templateUrl: './create-user.component.html',
  styleUrl: './create-user.component.css'
})
export class CreateUserComponent {
signupForm: FormGroup;
  responseMessage: string = '';
  isError: boolean = false;

  constructor(private fb: FormBuilder, private createUserService: CreateUserService) {
    this.signupForm = this.fb.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.signupForm.valid) {
      this.createUserService.registerUser(this.signupForm.value).subscribe({
        next: (res) => {
          this.isError = !res.status;
          this.responseMessage = res.message;
        },
        error: (err) => {
          this.isError = true;
          this.responseMessage = 'An error occurred while registering.';
        }
      });
    }
  }

}

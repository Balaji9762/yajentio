import { Component, OnInit, HostListener } from '@angular/core';
import {Topic, CourseTopicsService } from './course-topics.service';

@Component({
  selector: 'app-topics',
  standalone: false,
  templateUrl: './topics.component.html',
  styleUrl: './topics.component.css'
})
export class TopicsComponent implements OnInit {
  topicList: Topic[] = [];
  topic: Topic = { course: '', topics: '', description: '' };

  contextMenuVisible = false;
  contextMenuX = 0;
  contextMenuY = 0;
  selectedTopic: Topic | null = null;

  constructor(private courseTopicsService: CourseTopicsService) {}

  ngOnInit() {
    this.loadTopics();
  }

  loadTopics() {
    this.courseTopicsService.getAllTopics().subscribe(data => this.topicList = data);
  }

  onSubmit() {
    if (this.topic.id) {
      this.courseTopicsService.updateTopic(this.topic.id, this.topic).subscribe(() => {
        this.topic = { course: '', topics: '', description: '' };
        this.loadTopics();
      });
    } else {
      this.courseTopicsService.addTopic(this.topic).subscribe(() => {
        this.topic = { course: '', topics: '', description: '' };
        this.loadTopics();
      });
    }
  }

  onRightClick(event: MouseEvent, topic: Topic) {
    event.preventDefault();
    this.selectedTopic = topic;
    this.contextMenuVisible = true;
    this.contextMenuX = event.clientX;
    this.contextMenuY = event.clientY;
  }

  @HostListener('document:click')
  hideContextMenu() {
    this.contextMenuVisible = false;
  }

  editTopic(topic: Topic | null) {
    if (topic) {
      this.topic = { ...topic };
      this.contextMenuVisible = false;
    }
  }

  deleteTopic(id: number | undefined | null) {
    if (id) {
      this.courseTopicsService.deleteTopic(id).subscribe(() => this.loadTopics());
    }
    this.contextMenuVisible = false;
  }
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';



export interface Topic {
  id?: number;
  course: string;
  topics: string;
  description: string;
}
@Injectable({
  providedIn: 'root'
})
export class CourseTopicsService {

 baseUrl = environment.baseUrl;
 private apiUrl = environment.baseUrl+'http://3.108.126.170:8080';

 constructor(private http: HttpClient) {}

  getAllTopics(): Observable<Topic[]> {
    return this.http.get<Topic[]>(`${this.baseUrl}/getTopiclist`);
  }

  addTopic(topic: Topic): Observable<Topic> {
    return this.http.post<Topic>(`${this.baseUrl}/savetopiclist`, topic);
  }

  updateTopic(id: number, topic: Topic): Observable<Topic> {
    return this.http.put<Topic>(`${this.baseUrl}/updatedTopiclist/${id}`, topic);
  }

  deleteTopic(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteTopiclist/${id}`);
  }
}

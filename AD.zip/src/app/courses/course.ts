export interface Course {
  id?: number;
  coursename: string;
  courseoverview: string;
  trainername: string;
  platform: string;
  start_date: string;
  status: string;
  timing: string;
  courseimageurl: string;
}

import { Component, OnInit, HostListener } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CourseService, Course } from './course.service';

@Component({
  selector: 'app-courses',
  standalone: false,
  templateUrl: './courses.component.html',
  styleUrl: './courses.component.css'
})
export class CoursesComponent implements OnInit {
  courseForm!: FormGroup;
  courses: Course[] = [];
  isEditMode = false;
  editCourseId: number | null = null;

  contextMenuVisible = false;
  contextMenuX = 0;
  contextMenuY = 0;
  selectedCourse: Course | null = null;

  constructor(private fb: FormBuilder, private courseService: CourseService) {}

  ngOnInit(): void {
    this.courseForm = this.fb.group({

      coursename: ['', Validators.required],
      courseoverview: ['', Validators.required],
      trainername: ['', Validators.required],
      platform: ['', Validators.required],
     // courseurl: [''],
      timing: ['', Validators.required],
      start_date: ['', Validators.required],
      status: ['Yes'],
      courseimageurl: ['', Validators.required]
    });

    this.loadCourses();
  }

  loadCourses(): void {
    this.courseService.getCourses().subscribe({
      next: (data) => (this.courses = data),
      error: (err) => console.error('Error loading courses:', err)
    });
  }

  onSubmit(): void {
    if (this.courseForm.invalid) return;

    const courseData: Course = this.courseForm.value;

    if (this.isEditMode && this.editCourseId !== null) {
      this.courseService.updateCourse(this.editCourseId, courseData).subscribe({
        next: () => {
          alert('Course updated successfully!');
          this.resetForm();
          this.loadCourses();
        },
        error: () => alert('Update failed.')
      });
    } else {
      this.courseService.addCourse(courseData).subscribe({
        next: () => {
          alert('Course added!');
          this.resetForm();
          this.loadCourses();
        },
        error: () => alert('Error adding course.')
      });
    }
  }

  resetForm(): void {
    this.courseForm.reset();
    this.isEditMode = false;
    this.editCourseId = null;
  }

  onRightClick(event: MouseEvent, course: Course): void {
    event.preventDefault();
    this.contextMenuVisible = true;
    this.contextMenuX = event.clientX;
    this.contextMenuY = event.clientY;
    this.selectedCourse = course;
  }

  editCourse(): void {
    if (this.selectedCourse) {
      this.courseForm.patchValue(this.selectedCourse);
      this.isEditMode = true;
      this.editCourseId = this.selectedCourse.id ?? null;
    }
    this.contextMenuVisible = false;
  }

  deleteCourse(): void {
    if (this.selectedCourse && confirm('Delete this course?')) {
      this.courseService.deleteCourse(this.selectedCourse.id!).subscribe({
        next: () => {
          alert('Course deleted!');
          this.loadCourses();
        },
        error: () => alert('Failed to delete.')
      });
    }
    this.contextMenuVisible = false;
  }

  @HostListener('document:click')
  closeContextMenu(): void {
    this.contextMenuVisible = false;
  }
}

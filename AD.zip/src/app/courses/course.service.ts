import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface Course {
trainername: any;
coursename: any;
  id?: number;
  name :string;
  course_name: string;
  courseimageurl?: string;
  courseoverview: string;
  trainer_name: string;
  platform: string;
  courseurl?: string;
  timing: string;
  start_date: string;
  status: string;
}
@Injectable({
  providedIn: 'root'
})
export class CourseService {
 // private baseUrl = 'http://3.108.126.170:8080';
 baseUrl = environment.baseUrl;
  private apiUrl = environment.baseUrl+'http://3.108.126.170:8080';

  constructor(private http: HttpClient) {}

  getCourses(): Observable<Course[]> {
    return this.http.get<Course[]>(`${this.baseUrl}/getAllcourses`);
  }

  addCourse(course: Course): Observable<Course> {
    return this.http.post<Course>(`${this.baseUrl}/savecourse`, course);
  }

  updateCourse(id: number, course: Course): Observable<Course> {
    return this.http.put<Course>(`${this.baseUrl}/updatedcourse/${id}`, course);
  }

  deleteCourse(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deletecourse/${id}`);
  }
}

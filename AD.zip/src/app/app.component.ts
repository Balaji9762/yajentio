import { Component, OnInit } from '@angular/core';
import { AuthService } from './login/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = "razorpay-docs";
  isLoggedIn: boolean = false;

  constructor(private authService: AuthService) {}

  ngOnInit() {
    // Initialize isLoggedIn using the AuthService
    this.isLoggedIn = this.authService.isLoggedIn();

    // Subscribe to auth changes if needed
    this.authService.authStateChanged().subscribe(isLoggedIn => {
      this.isLoggedIn = isLoggedIn;
    });
  }
}

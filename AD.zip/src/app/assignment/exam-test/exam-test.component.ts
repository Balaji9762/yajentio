import { Component, type OnInit, type OnDestroy } from '@angular/core';
import  { ActivatedRoute, Router } from "@angular/router"
//import  { ExamService } from "src/app/services/exam.service" // Ensure correct import path
import { ExamService } from '../exam.service';
//import type { Question, SelectedAnswer } from "../../models/exam.model" // Import interfaces
import { Question, SelectedAnswer, SubmitRequest, SubmitResponse } from '../exam';
@Component({
  selector: 'app-exam-test',
  standalone: false,
  templateUrl: './exam-test.component.html',
  styleUrl: './exam-test.component.css'
})
export class ExamTestComponent implements OnInit, OnDestroy {
   courseId!: number
  questions: Question[] = []
  selectedAnswers: SelectedAnswer = {}
  timeLeft = 20 * 60 // 20 minutes in seconds
  timer: any
  isLoadingQuestions = true // New state for loading indicator

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private examService: ExamService,
  ) {}

  ngOnInit(): void {
    this.courseId = Number(this.route.snapshot.paramMap.get("courseId"))
    if (isNaN(this.courseId)) {
      this.router.navigate(["/"])
      return
    }

    this.examService.getAllQuestions(this.courseId).subscribe(
      (data) => {
        this.questions = data
        this.isLoadingQuestions = false
        this.startTimer()
      },
      (error) => {
        console.error("Error fetching questions:", error)
        this.isLoadingQuestions = false
        // Handle error, e.g., display a message and redirect
        alert("Failed to load questions. Please try again.")
        this.router.navigate(["/"])
      },
    )
  }

  ngOnDestroy(): void {
    if (this.timer) {
      clearInterval(this.timer)
    }
  }

  startTimer() {
    this.timer = setInterval(() => {
      this.timeLeft--
      if (this.timeLeft <= 0) {
        clearInterval(this.timer)
        alert("Time's up!")
        this.submitExam()
      }
    }, 1000)
  }

  formatTime(): string {
    const m = Math.floor(this.timeLeft / 60)
    const s = this.timeLeft % 60
    return `${m}:${s < 10 ? "0" : ""}${s}`
  }

  submitExam() {
    if (this.timer) {
      clearInterval(this.timer)
    }

    const submitRequest: SubmitRequest = {
      courseId: this.courseId,
      answers: this.selectedAnswers,
    }

    this.examService.submitExam(submitRequest).subscribe(
      (response: SubmitResponse) => {
        alert(`Your score is ${response.score}/${response.total}`)
        this.router.navigate(["/"])
      },
      (error) => {
        console.error("Error submitting exam:", error)
        alert("Failed to submit exam. Please try again.")
      },
    )
  }
}

import { Component, type OnInit } from '@angular/core';
import  { Router } from "@angular/router"
import { ExamService } from './exam.service';
import { Course} from './exam';
@Component({
  selector: 'app-assignment',
  standalone: false,
  templateUrl: './assignment.component.html',
  styleUrl: './assignment.component.css'
})
export class AssignmentComponent implements OnInit {
 courses: Course[] = [] // Initialize as empty array

  constructor(
    private router: Router,
    private examService: ExamService,
  ) {} // Inject ExamService

  ngOnInit(): void {
    this.examService.fetchAllCourses().subscribe(
      (data) => {
        this.courses = data
      },
      (error) => {
        console.error("Error fetching courses:", error)
        // Handle error, e.g., display a message to the user
      },
    )
  }

  startExam(courseId: number) {
    this.router.navigate(["/exam", courseId])
  }
}

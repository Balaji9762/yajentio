export interface Course {
   id: number
  name: string
  imageurl: string
}

export interface Question {
  id: number
  question: string
  options: string[]
  correct: string
}

export interface SubmitRequest {
  courseId: number
  answers: { [questionId: number]: string }
}

export interface SubmitResponse {
  score: number
  total: number
}

export type SelectedAnswer = { [questionId: string]: string };

export interface SubmitRequest {
  courseId: number;
  answers: { [questionId: number]: string };
}

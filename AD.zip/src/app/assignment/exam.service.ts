import { Injectable } from '@angular/core';
import  { HttpClient } from "@angular/common/http" // Import HttpClient
import type { Observable } from "rxjs" // Import Observable
//import type { Course, Question, SubmitRequest, SubmitResponse } from "../models/exam.model" // Import all models
import { Course, Question, SubmitRequest, SubmitResponse  } from './exam';
@Injectable({
  providedIn: 'root'
})
export class ExamService {
private baseUrl = "http://3.108.126.170:8080" // Your API base URL

  constructor(private http: HttpClient) {} // Inject HttpClient

  fetchAllCourses(): Observable<Course[]> {
    return this.http.get<Course[]>(`${this.baseUrl}/fetchAllcourses`)
  }

  getAllQuestions(courseId: number): Observable<Question[]> {
    return this.http.get<Question[]>(`${this.baseUrl}/getAllquestions/${courseId}`)
  }

  submitExam(request: SubmitRequest): Observable<SubmitResponse> {
    return this.http.post<SubmitResponse>(`${this.baseUrl}/submit`, request)
  }

  generateQuestions(courseId: number): Question[] {
    // Use the Question interface
    const courseName = this.getCourseName(courseId)
    const questionsData: Question[] = [
      // Use the Question interface
      {
        id: 1,
        question: `For ${courseName}: What is the primary purpose of a constructor in a class?`,
        options: [
          "To destroy an object",
          "To initialize an object's state",
          "To define static methods",
          "To declare variables",
        ],
        correct: "To initialize an object's state",
      },
      {
        id: 2,
        question: `For ${courseName}: Which of these is a version control system?`,
        options: ["Jira", "Slack", "Git", "Trello"],
        correct: "Git",
      },
      {
        id: 3,
        question: `For ${courseName}: What does API stand for?`,
        options: [
          "Application Programming Interface",
          "Advanced Protocol Integration",
          "Automated Program Instruction",
          "Application Process Interaction",
        ],
        correct: "Application Programming Interface",
      },
      {
        id: 4,
        question: `For ${courseName}: Which data structure uses LIFO (Last In, First Out) principle?`,
        options: ["Queue", "Array", "Stack", "Linked List"],
        correct: "Stack",
      },
      {
        id: 5,
        question: `For ${courseName}: What is the main benefit of using a framework like Angular/React/Vue?`,
        options: [
          "Faster database queries",
          "Simplified UI development and component reusability",
          "Automatic code generation",
          "Improved network latency",
        ],
        correct: "Simplified UI development and component reusability",
      },
      {
        id: 6,
        question: `For ${courseName}: What is the purpose of 'npm' in Node.js development?`,
        options: ["Network Packet Manager", "Node Package Manager", "New Project Maker", "Native Process Monitor"],
        correct: "Node Package Manager",
      },
      {
        id: 7,
        question: `For ${courseName}: Which HTTP method is typically used to retrieve data from a server?`,
        options: ["POST", "PUT", "DELETE", "GET"],
        correct: "GET",
      },
    ]

    return questionsData
  }

  private getCourseName(courseId: number): string {
    const courses: { [key: number]: string } = {
      1: "Python Full Stack",
      2: "Java Full Stack",
      3: "Angular Developer",
      4: "React Developer",
      5: "Data Science",
      6: "DevOps Engineer",
      7: "AI/ML Engineer",
    }
    return courses[courseId] || "Unknown Course"
  }
}

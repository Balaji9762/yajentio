import { Injectable } from '@angular/core';
import  { HttpClient } from "@angular/common/http"
import type { Observable } from "rxjs"
import { Contact } from './contact';


@Injectable({
  providedIn: 'root'
})
export class ContactServiceService {
  private apiUrl = "http://3.108.126.170:8080"

  constructor(private http: HttpClient) {}

  // Create new contact
  saveContact(contact: Contact): Observable<Contact> {
    return this.http.post<Contact>(`${this.apiUrl}/savecontact`, contact)
  }

  // Get all contacts
  getAllContacts(): Observable<Contact[]> {
    return this.http.get<Contact[]>(`${this.apiUrl}/getAllcontact`)
  }

  // Update contact
  updateContact(id: number, contact: Contact): Observable<Contact> {
    // Make a copy of the contact object to avoid modifying the original
    const contactData = { ...contact };
    // Ensure the ID in the URL and body match
    return this.http.put<Contact>(`${this.apiUrl}/updatecontact/${id}`, contactData)
  }

  // Delete contact
  deleteContact(id: number): Observable<string> {
    return this.http.delete(`${this.apiUrl}/deletecontact/${id}`, { responseType: 'text' })
  }

  // Download contacts PDF
  downloadContacts(): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/downloadcontacts`, { responseType: "blob" })
  }
}

export interface Contact {
   id?: number
  name: string
  email: string
  phone_no: string
  category: string
  course: string
  other_courses: string
  training_type: string
  preferred_city: string
  message: string
  status: string
}

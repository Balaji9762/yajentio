import { Component, OnInit } from '@angular/core';
import {  FormBuilder,  FormGroup, Validators } from "@angular/forms"
import { ContactServiceService} from './contact-service.service';
import { Contact } from './contact';
@Component({
  selector: 'app-contact-details',
  standalone: false,
  templateUrl: './contact-details.component.html',
  styleUrl: './contact-details.component.css'
})
export class ContactDetailsComponent implements OnInit {
   contacts: Contact[] = []
  contactForm: FormGroup
  editingId: number | null = null
  isLoading = false
  error: string | null = null
  success: string | null = null
  showForm = false

  // Context menu properties
  contextMenuVisible = false
  contextMenuPosition = { x: 0, y: 0 }
  contextMenuItem: Contact | null = null

  // Dropdown options
  categoryOptions = ["Student", "Professional", "Corporate", "Individual"]
  courseOptions = [
    "Java",
    "Python",
    "JavaScript",
    "React",
    "Angular",
    "Node.js",
    "Spring Boot",
    "Data Science",
    "Machine Learning",
    "DevOps",
    "Testing",
    "UI/UX Design",
  ]
  trainingTypeOptions = ["Online", "Offline", "Hybrid"]
  cityOptions = [
    "Mumbai",
    "Delhi",
    "Bangalore",
    "Chennai",
    "Kolkata",
    "Hyderabad",
    "Pune",
    "Ahmedabad",
    "Jaipur",
    "Lucknow",
  ]
  statusOptions = ["New", "In Progress", "Contacted", "Closed", "Rejected"]

  constructor(
    private contactServiceService: ContactServiceService,
    private fb: FormBuilder,
  ) {
    this.contactForm = this.fb.group({
      name: ["", [Validators.required, Validators.minLength(2)]],
      email: ["", [Validators.required, Validators.email]],
      phone_no: ["", [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      category: ["", Validators.required],
      course: ["", Validators.required],
      other_courses: [""],
      training_type: ["", Validators.required],
      preferred_city: ["", Validators.required],
      message: ["", [Validators.required, Validators.minLength(10)]],
      status: ["New", Validators.required],
    })
  }

  ngOnInit(): void {
    this.loadContacts()

    // Handle clicks outside context menu
    document.addEventListener("click", (event) => {
      if (this.contextMenuVisible) {
        const target = event.target as HTMLElement
        if (!target.closest(".context-menu")) {
          this.closeContextMenu()
        }
      }
    })

    // Handle escape key
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && this.contextMenuVisible) {
        this.closeContextMenu()
      }
    })

    // Prevent default context menu on the entire table
    document.addEventListener("contextmenu", (event) => {
      const target = event.target as HTMLElement
      if (target.closest(".table-row")) {
        event.preventDefault()
      }
    })
  }

  loadContacts(): void {
    this.isLoading = true
    this.contactServiceService.getAllContacts().subscribe({
      next: (data) => {
        this.contacts = data
        this.isLoading = false
      },
      error: (err) => {
        this.error = "Failed to load contacts. Please try again."
        this.isLoading = false
        console.error("Error loading contacts:", err)
      },
    })
  }

  onSubmit(): void {
    if (this.contactForm.invalid) {
      this.markFormGroupTouched(this.contactForm)
      return
    }

    this.isLoading = true
    const contactData = this.contactForm.value

    if (this.editingId) {
      // Update existing contact
      // Include the ID in the contact data for the update
      const contactWithId = {
        ...contactData,
        id: this.editingId
      }

      console.log("Updating contact with data:", contactWithId)

      // Add a small delay to ensure any previous operations are complete
      setTimeout(() => {
        // Ensure editingId is not null before passing to updateContact
        if (this.editingId !== null) {
          this.contactServiceService.updateContact(this.editingId, contactWithId).subscribe({
            next: (updatedContact) => {
              console.log("Contact updated successfully:", updatedContact)
              this.success = "Contact updated successfully!"
              this.loadContacts()
              this.resetForm()
              this.isLoading = false
              this.showForm = false; // Hide the form after successful update
            },
            error: (err) => {
              console.error("Error updating contact:", err)
              this.error = `Failed to update contact: ${err.message || "Unknown error"}. Please try again.`
              this.isLoading = false
            },
          })
        } else {
          console.error("Cannot update contact: ID is null")
          this.error = "Failed to update contact: Invalid ID. Please try again."
          this.isLoading = false
        }
      }, 100)
    } else {
      // Create new contact
      console.log("Creating new contact with data:", contactData)

      this.contactServiceService.saveContact(contactData).subscribe({
        next: (newContact) => {
          console.log("Contact created successfully:", newContact)
          this.success = "Contact created successfully!"
          this.loadContacts()
          this.resetForm()
          this.isLoading = false
          this.showForm = false; // Hide the form after successful creation
        },
        error: (err) => {
          console.error("Error creating contact:", err)
          this.error = `Failed to create contact: ${err.message || "Unknown error"}. Please try again.`
          this.isLoading = false
        },
      })
    }
  }

  onRightClick(event: MouseEvent, contact: Contact): void {
    // Prevent default context menu and stop all event propagation
    event.preventDefault()
    event.stopPropagation()
    event.stopImmediatePropagation()

    // Close any existing context menu first
    this.closeContextMenu()

    // Calculate position for context menu with better logic
    const menuWidth = 220
    const menuHeight = 180
    const windowWidth = window.innerWidth
    const windowHeight = window.innerHeight
    const scrollX = window.pageXOffset || document.documentElement.scrollLeft
    const scrollY = window.pageYOffset || document.documentElement.scrollTop

    let x = event.pageX
    let y = event.pageY

    // Adjust position if menu would go off screen
    if (x + menuWidth > windowWidth + scrollX) {
      x = windowWidth + scrollX - menuWidth - 10
    }
    if (y + menuHeight > windowHeight + scrollY) {
      y = windowHeight + scrollY - menuHeight - 10
    }

    // Ensure minimum distance from edges
    x = Math.max(10, x)
    y = Math.max(10, y)

    // Set context menu properties
    this.contextMenuPosition = { x, y }
    this.contextMenuItem = contact
    this.contextMenuVisible = true

    console.log("Right-click menu opened for contact:", contact.name, "at position:", { x, y })

    // Prevent event bubbling to document
    setTimeout(() => {
      document.addEventListener("click", this.handleDocumentClick.bind(this), { once: true })
    }, 0)
  }

  private handleDocumentClick(event: Event): void {
    const target = event.target as HTMLElement
    if (!target.closest(".context-menu")) {
      this.closeContextMenu()
    }
  }

  editContact(): void {
    if (!this.contextMenuItem) {
      console.error("No context menu item selected")
      return
    }

    console.log("Editing contact:", this.contextMenuItem)

    // Set editing ID
    this.editingId = this.contextMenuItem.id!

    // Create a clean copy of the contact data
    const contactData = {
      name: this.contextMenuItem.name || "",
      email: this.contextMenuItem.email || "",
      phone_no: this.contextMenuItem.phone_no || "",
      category: this.contextMenuItem.category || "",
      course: this.contextMenuItem.course || "",
      other_courses: this.contextMenuItem.other_courses || "",
      training_type: this.contextMenuItem.training_type || "",
      preferred_city: this.contextMenuItem.preferred_city || "",
      message: this.contextMenuItem.message || "",
      status: this.contextMenuItem.status || "New",
    }

    // Populate the form
    this.contactForm.patchValue(contactData)

    // Show the form
    this.showForm = true

    // Close context menu
    this.closeContextMenu()

    // Clear any existing messages
    this.clearMessages()

    // Scroll to form with a delay to ensure it's rendered
    setTimeout(() => {
      const formElement = document.querySelector(".form-section")
      if (formElement) {
        formElement.scrollIntoView({ behavior: "smooth", block: "start" })
      }
    }, 200)

    console.log("Form populated with data:", contactData)
  }

  deleteContact(): void {
    if (!this.contextMenuItem) {
      console.error("No context menu item selected")
      return
    }

    const contactName = this.contextMenuItem.name
    const contactId = this.contextMenuItem.id!

    console.log("Attempting to delete contact:", contactName, "with ID:", contactId)

    // Close context menu first
    this.closeContextMenu()

    if (confirm(`Are you sure you want to delete contact "${contactName}"?\n\nThis action cannot be undone.`)) {
      this.isLoading = true
      this.clearMessages()

      // Add a delay to ensure context menu is fully closed
      setTimeout(() => {
        this.contactServiceService.deleteContact(contactId).subscribe({
          next: (response) => {
            console.log("Delete response:", response)
            this.success = `Contact "${contactName}" has been deleted successfully!`
            this.loadContacts() // Reload the contacts list
            this.isLoading = false
          },
          error: (err) => {
            console.error("Error deleting contact:", err)
            this.error = `Failed to delete contact "${contactName}". ${err.error?.message || err.message || "Please try again."}`
            this.isLoading = false
          },
        })
      }, 100)
    }
  }

  downloadPDF(): void {
    console.log("Starting PDF download...")

    // Close context menu first
    this.closeContextMenu()

    this.isLoading = true
    this.clearMessages()

    this.contactServiceService.downloadContacts().subscribe({
      next: (blob) => {
        console.log("PDF blob received:", blob)

        try {
          // Create a URL for the blob
          const url = window.URL.createObjectURL(blob)

          // Create a link element and trigger download
          const link = document.createElement("a")
          link.href = url
          link.download = `contacts_${new Date().toISOString().split("T")[0]}.pdf`
          link.style.display = "none"

          // Add to DOM, click, and remove
          document.body.appendChild(link)
          link.click()
          document.body.removeChild(link)

          // Clean up the URL
          setTimeout(() => {
            window.URL.revokeObjectURL(url)
          }, 100)

          this.success = "PDF downloaded successfully!"
          console.log("PDF download completed")
        } catch (error) {
          console.error("Error creating download link:", error)
          this.error = "Failed to download PDF. Please try again."
        }

        this.isLoading = false
      },
      error: (err) => {
        console.error("Error downloading PDF:", err)
        this.error = `Failed to download PDF. ${err.error?.message || err.message || "Please try again."}`
        this.isLoading = false
      },
    })
  }

  closeContextMenu(): void {
    this.contextMenuVisible = false
    this.contextMenuItem = null
    console.log("Context menu closed")

    // Remove any lingering event listeners
    document.removeEventListener("click", this.handleDocumentClick.bind(this))
  }

  toggleForm(): void {
    this.showForm = !this.showForm
    if (!this.showForm) {
      this.resetForm()
    }
  }

  resetForm(): void {
    this.contactForm.reset()
    this.contactForm.patchValue({ status: "New" })
    this.editingId = null
  }

  clearMessages(): void {
    this.error = null
    this.success = null
  }

  getContactInitials(name: string): string {
    if (!name) return "?"
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2)
  }

  getStatusBadgeClass(status: string): string {
    switch (status?.toLowerCase()) {
      case "new":
        return "status-new"
      case "in progress":
        return "status-progress"
      case "contacted":
        return "status-contacted"
      case "closed":
        return "status-closed"
      case "rejected":
        return "status-rejected"
      default:
        return "status-default"
    }
  }

  getTrainingTypeBadgeClass(trainingType: string): string {
    switch (trainingType?.toLowerCase()) {
      case "online":
        return "training-online"
      case "offline":
        return "training-offline"
      case "hybrid":
        return "training-hybrid"
      default:
        return "training-default"
    }
  }

  truncateMessage(message: string, maxLength = 50): string {
    if (!message) return "N/A"
    return message.length > maxLength ? message.substring(0, maxLength) + "..." : message
  }

  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((key) => {
      const control = formGroup.get(key)
      control?.markAsTouched()
    })
  }
}

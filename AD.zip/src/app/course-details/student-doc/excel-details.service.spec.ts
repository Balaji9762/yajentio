import { TestBed } from '@angular/core/testing';

import { ExcelDetailsService } from './excel-details.service';

describe('ExcelDetailsService', () => {
  let service: ExcelDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ExcelDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

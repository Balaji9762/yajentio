import { Injectable } from '@angular/core';
import  { HttpClient } from "@angular/common/http"
import  { Observable } from "rxjs"
import { ExcelDetails } from './excel-details';
@Injectable({
  providedIn: 'root'
})
export class ExcelDetailsService {

  private baseUrl = "http://3.108.126.170:8080"

  constructor(private http: HttpClient) {}

  // Upload Excel file
  uploadExcel(file: File): Observable<string> {
    const formData = new FormData()
    formData.append("file", file)

    return this.http.post(`${this.baseUrl}/Exceldetailsupload`, formData, {
      responseType: "text",
    })
  }

  // Get all records
  getAllDetails(): Observable<ExcelDetails[]> {
    return this.http.get<ExcelDetails[]>(`${this.baseUrl}/Exceldetailsgetall`)
  }

  // Update record
  updateDetails(id: number, details: ExcelDetails): Observable<ExcelDetails> {
    return this.http.put<ExcelDetails>(`${this.baseUrl}/Exceldetailsupdate/${id}`, details)
  }

  // Delete record
  deleteDetails(id: number): Observable<string> {
    return this.http.delete(`${this.baseUrl}/Exceldetailsdelete/${id}`, {
      responseType: "text",
    })
  }
}

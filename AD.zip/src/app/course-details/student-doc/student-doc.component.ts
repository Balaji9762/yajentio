import { Component, type OnInit } from '@angular/core';
import { ExcelDetails } from './excel-details';
import { ExcelDetailsService } from './excel-details.service';

@Component({
  selector: 'app-student-doc',
  standalone: false,
  templateUrl: './student-doc.component.html',
  styleUrl: './student-doc.component.css'
})
export class StudentDocComponent implements OnInit {
  excelDetails: ExcelDetails[] = []
  selectedFile: File | null = null
  isUploading = false
  editingRecord: ExcelDetails | null = null
  showEditForm = false
  loading = false
  message = ""
  messageType: "success" | "error" = "success"

  showContextMenu = false
  contextMenuX = 0
  contextMenuY = 0
  selectedRecord: ExcelDetails | null = null

  constructor(private excelService: ExcelDetailsService) {}

  ngOnInit(): void {
    this.loadAllDetails()
    document.addEventListener("click", () => {
      this.closeContextMenu()
    })
  }

  // Load all records
  loadAllDetails(): void {
    this.loading = true
    this.excelService.getAllDetails().subscribe({
      next: (data) => {
        this.excelDetails = data
        this.loading = false
      },
      error: (error) => {
        console.error("Error loading data:", error)
        this.showMessage("Error loading data", "error")
        this.loading = false
      },
    })
  }

  // Handle file selection
  onFileSelected(event: any): void {
    const file = event.target.files[0]
    if (file && file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
      this.selectedFile = file
    } else {
      this.showMessage("Please select a valid Excel file (.xlsx)", "error")
      this.selectedFile = null
    }
  }

  // Upload Excel file
  uploadExcel(): void {
    if (!this.selectedFile) {
      this.showMessage("Please select a file first", "error")
      return
    }

    this.isUploading = true
    this.excelService.uploadExcel(this.selectedFile).subscribe({
      next: (response) => {
        this.showMessage("Excel uploaded successfully!", "success")
        this.selectedFile = null
        this.isUploading = false
        this.loadAllDetails() // Refresh the table
        // Reset file input
        const fileInput = document.getElementById("fileInput") as HTMLInputElement
        if (fileInput) fileInput.value = ""
      },
      error: (error) => {
        console.error("Upload error:", error)
        this.showMessage("Upload failed. Please try again.", "error")
        this.isUploading = false
      },
    })
  }

  // Start editing a record
  editRecord(record: ExcelDetails): void {
    this.editingRecord = { ...record }
    this.showEditForm = true
  }

  // Save edited record
  saveRecord(): void {
    if (!this.editingRecord || !this.editingRecord.id) return

    this.excelService.updateDetails(this.editingRecord.id, this.editingRecord).subscribe({
      next: (updatedRecord) => {
        const index = this.excelDetails.findIndex((r) => r.id === updatedRecord.id)
        if (index !== -1) {
          this.excelDetails[index] = updatedRecord
        }
        this.showMessage("Record updated successfully!", "success")
        this.cancelEdit()
      },
      error: (error) => {
        console.error("Update error:", error)
        this.showMessage("Update failed. Please try again.", "error")
      },
    })
  }

  // Cancel editing
  cancelEdit(): void {
    this.editingRecord = null
    this.showEditForm = false
  }

  // Delete record
  deleteRecord(id: number): void {
    if (confirm("Are you sure you want to delete this record?")) {
      this.excelService.deleteDetails(id).subscribe({
        next: (response) => {
          this.excelDetails = this.excelDetails.filter((record) => record.id !== id)
          this.showMessage("Record deleted successfully!", "success")
        },
        error: (error) => {
          console.error("Delete error:", error)
          this.showMessage("Delete failed. Please try again.", "error")
        },
      })
    }
  }

  // Show message
  showMessage(text: string, type: "success" | "error"): void {
    this.message = text
    this.messageType = type
    setTimeout(() => {
      this.message = ""
    }, 5000)
  }

  // Handle right-click on table row
  onRightClick(event: MouseEvent, record: ExcelDetails): void {
    event.preventDefault()
    this.selectedRecord = record
    this.contextMenuX = event.clientX
    this.contextMenuY = event.clientY
    this.showContextMenu = true
  }

  // Handle context menu actions
  onContextMenuEdit(): void {
    if (this.selectedRecord) {
      this.editRecord(this.selectedRecord)
    }
    this.closeContextMenu()
  }

  onContextMenuDelete(): void {
    if (this.selectedRecord && this.selectedRecord.id) {
      this.deleteRecord(this.selectedRecord.id)
    }
    this.closeContextMenu()
  }

  // Close context menu
  closeContextMenu(): void {
    this.showContextMenu = false
    this.selectedRecord = null
  }

  // Track by function for ngFor performance
  trackByFn(index: number, item: ExcelDetails): number {
    return item.id || index
  }
}

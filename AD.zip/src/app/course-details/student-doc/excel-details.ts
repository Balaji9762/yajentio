export interface ExcelDetails {
  id?: number
  firstname: string
  lastname: string
  email: string
  phone: string
  courses: string
}

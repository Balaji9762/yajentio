export interface Student {
  id: number
  sd_course_name: string
  sd_email: string
  sd_phno: string
  sd_course_start_date: string
  sd_course_end_date: string
  sd_student_name: string
  status?: string
}

import { Component, OnInit } from '@angular/core';
import {  FormBuilder, FormGroup, Validators } from "@angular/forms"
import { StudentService } from './student.service';
import { Student } from './student';
@Component({
  selector: 'app-student-details',
  standalone: false,
  templateUrl: './student-details.component.html',
  styleUrl: './student-details.component.css'
})
export class StudentDetailsComponent implements OnInit {
  students: Student[] = []
  studentForm: FormGroup
  editingId: number | null = null
  isLoading = false
  error: string | null = null
  success: string | null = null

  // Context menu properties
  contextMenuVisible = false
  contextMenuPosition = { x: 0, y: 0 }
  contextMenuItem: Student | null = null

  // Course options
  courseOptions = [
    "Java Fullstack",
    "Frontend Development",
    "Backend Development",
    "Testing",
    "DevOps",
    "Data Science",
    "Mobile Development",
    "UI/UX Design",
    "Python Development",
    "React Development",
    "Angular Development",
    "Node.js Development",
  ]

  // Status options
  statusOptions = [
    { value: "active", label: "Active", color: "bg-green-100 text-green-800" },
    { value: "inactive", label: "Inactive", color: "bg-red-100 text-red-800" },
  ]

  constructor(
    private studentService: StudentService,
    private fb: FormBuilder,
  ) {
    this.studentForm = this.fb.group({
      sd_student_name: ["", [Validators.required, Validators.minLength(2)]],
      sd_course_name: ["", Validators.required],
      sd_email: ["", [Validators.required, Validators.email]],
      sd_phno: ["", [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      sd_course_start_date: ["", Validators.required],
      sd_course_end_date: ["", Validators.required],
      status: ["active", Validators.required], // Default to active
    })
  }

  ngOnInit(): void {
    this.loadStudents()

    // Close context menu when clicking outside
    document.addEventListener("click", () => {
      this.contextMenuVisible = false
    })

    // Add custom validator for date range
    this.studentForm.get("sd_course_end_date")?.valueChanges.subscribe(() => {
      this.validateDateRange()
    })

    this.studentForm.get("sd_course_start_date")?.valueChanges.subscribe(() => {
      this.validateDateRange()
    })
  }

  validateDateRange(): void {
    const startDate = this.studentForm.get("sd_course_start_date")?.value
    const endDate = this.studentForm.get("sd_course_end_date")?.value

    if (startDate && endDate && new Date(startDate) >= new Date(endDate)) {
      this.studentForm.get("sd_course_end_date")?.setErrors({ dateRange: true })
    }
  }

  loadStudents(): void {
    this.isLoading = true
    this.studentService.getStudents().subscribe({
      next: (data) => {
        // Add default status if not present
        this.students = data.map((student) => ({
          ...student,
          status: student.status || "active",
        }))
        this.isLoading = false
      },
      error: (err) => {
        this.error = "Failed to load students. Please try again."
        this.isLoading = false
        console.error("Error loading students:", err)
      },
    })
  }

  onSubmit(): void {
    if (this.studentForm.invalid) {
      this.markFormGroupTouched(this.studentForm)
      return
    }

    this.isLoading = true
    const studentData = this.studentForm.value

    if (this.editingId) {
      this.studentService.updateStudent(this.editingId, studentData).subscribe({
        next: (updatedStudent) => {
          this.success = "Student updated successfully!"
          this.loadStudents()
          this.resetForm()
          this.isLoading = false
        },
        error: (err) => {
          this.error = "Failed to update student. Please try again."
          this.isLoading = false
          console.error("Error updating student:", err)
        },
      })
    } else {
      this.studentService.createStudent(studentData).subscribe({
        next: (newStudent) => {
          this.success = "Student created successfully!"
          this.loadStudents()
          this.resetForm()
          this.isLoading = false
        },
        error: (err) => {
          this.error = "Failed to create student. Please try again."
          this.isLoading = false
          console.error("Error creating student:", err)
        },
      })
    }
  }

  onRightClick(event: MouseEvent, student: Student): void {
    event.preventDefault()
    this.contextMenuVisible = true
    this.contextMenuPosition = { x: event.clientX, y: event.clientY }
    this.contextMenuItem = student
  }

  edit(student: Student): void {
    this.editingId = student.id
    this.studentForm.patchValue({
      sd_student_name: student.sd_student_name,
      sd_course_name: student.sd_course_name,
      sd_email: student.sd_email,
      sd_phno: student.sd_phno,
      sd_course_start_date: student.sd_course_start_date,
      sd_course_end_date: student.sd_course_end_date,
      status: student.status || "active",
    })
    this.contextMenuVisible = false

    // Scroll to form
    const formElement = document.querySelector("form")
    if (formElement) {
      formElement.scrollIntoView({ behavior: "smooth", block: "start" })
    }
  }

  delete(id: number): void {
    if (confirm("Are you sure you want to delete this student?")) {
      this.isLoading = true
      this.studentService.deleteStudent(id).subscribe({
        next: (response) => {
          this.success = "Student deleted successfully!"
          this.loadStudents()
          this.isLoading = false
          this.contextMenuVisible = false
        },
        error: (err) => {
          this.error = "Failed to delete student. Please try again."
          this.isLoading = false
          console.error("Error deleting student:", err)
        },
      })
    } else {
      this.contextMenuVisible = false
    }
  }

  resetForm(): void {
    this.studentForm.reset()
    this.studentForm.patchValue({ status: "active" }) // Reset to default active status
    this.editingId = null
  }

  clearMessages(): void {
    this.error = null
    this.success = null
  }

  formatDate(dateString: string): string {
    if (!dateString) return "N/A"
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  getStudentInitials(name: string): string {
    if (!name) return "?"
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2)
  }

  getStatusBadgeClass(status: string): string {
    const statusOption = this.statusOptions.find((s) => s.value === status)
    return statusOption ? statusOption.color : "bg-gray-100 text-gray-800"
  }

  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((key) => {
      const control = formGroup.get(key)
      control?.markAsTouched()
    })
  }
}

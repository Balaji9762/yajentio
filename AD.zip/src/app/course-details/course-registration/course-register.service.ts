import { Injectable } from '@angular/core';
import  { HttpClient, HttpErrorResponse } from "@angular/common/http"
import { type Observable, throwError } from "rxjs"
import { catchError } from "rxjs/operators"
import { CourseRegister, ApiResponse } from './course-register';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CourseRegisterService {

  private apiUrl = environment.apiUrl

  constructor(private http: HttpClient) {}

  // Get all registrations
  getAllRegistrations(): Observable<CourseRegister[]> {
    return this.http.get<CourseRegister[]>(`${this.apiUrl}/getAllRegister`).pipe(catchError(this.handleError))
  }

  // Create new registration
  createRegistration(registration: CourseRegister): Observable<CourseRegister> {
    return this.http
      .post<CourseRegister>(`${this.apiUrl}/saveRegister`, registration)
      .pipe(catchError(this.handleError))
  }

  // Update existing registration
  updateRegistration(id: number, registration: CourseRegister): Observable<CourseRegister> {
    return this.http
      .put<CourseRegister>(`${this.apiUrl}/updatedRegister/${id}`, registration)
      .pipe(catchError(this.handleError))
  }

  // Delete registration
  deleteRegistration(id: number): Observable<ApiResponse> {
    return this.http.delete<ApiResponse>(`${this.apiUrl}/deleteregister/${id}`).pipe(catchError(this.handleError))
  }

  // Error handling
  private handleError(error: HttpErrorResponse) {
    let errorMessage = "An unknown error occurred!"

    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Error: ${error.error.message}`
    } else {
      // Server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`
    }

    console.error(errorMessage)
    return throwError(() => errorMessage)
  }
}

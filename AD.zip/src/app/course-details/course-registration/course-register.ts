export interface CourseRegister {
 id?: number
  full_name: string
  email: string
  country_code: string
  whatsapp_number: string
}

export interface ApiResponse {
  message: string
}

export interface Country {
  code: string
  name: string
}

import { Component, type OnInit } from '@angular/core';
import {  FormBuilder,  FormGroup, Validators } from "@angular/forms"
import { CourseRegisterService } from './course-register.service';
import { CourseRegister, Country } from './course-register';
@Component({
  selector: 'app-course-registration',
  standalone: false,
  templateUrl: './course-registration.component.html',
  styleUrl: './course-registration.component.css'
})
export class CourseRegistrationComponent implements OnInit {
  registrationForm!: FormGroup
  registrations: CourseRegister[] = []
  isEditing = false
  editingId: number | null = null
  isLoading = false
  message = ""
  messageType: "success" | "error" = "success"

  countries: Country[] = [
    { code: "India", name: "India" },
    { code: "USA", name: "United States" },
    { code: "UK", name: "United Kingdom" },
    { code: "Canada", name: "Canada" },
    { code: "Australia", name: "Australia" },
    { code: "Germany", name: "Germany" },
    { code: "France", name: "France" },
    { code: "Japan", name: "Japan" },
    { code: "Singapore", name: "Singapore" },
    { code: "UAE", name: "United Arab Emirates" },
  ]

  // Add these properties after the existing ones
  showContextMenu = false
  contextMenuX = 0
  contextMenuY = 0
  selectedRegistration: CourseRegister | null = null

  constructor(
    private fb: FormBuilder,
    private courseRegisterService: CourseRegisterService,
  ) {
    this.initializeForm()
  }

  ngOnInit(): void {
    this.loadRegistrations()
  }

  private initializeForm(): void {
    this.registrationForm = this.fb.group({
      full_name: ["", [Validators.required, Validators.minLength(2)]],
      email: ["", [Validators.required, Validators.email]],
      country_code: ["", [Validators.required]],
      whatsapp_number: ["", [Validators.required, Validators.pattern(/^\d{10,15}$/)]],
    })
  }

  loadRegistrations(): void {
    this.courseRegisterService.getAllRegistrations().subscribe({
      next: (data) => {
        this.registrations = data
      },
      error: (error) => {
        console.error("Error loading registrations:", error)
        this.showMessage("Error loading registrations", "error")
      },
    })
  }

  onSubmit(): void {
    if (this.registrationForm.valid) {
      this.isLoading = true
      const formData = this.registrationForm.value

      if (this.isEditing && this.editingId) {
        this.updateRegistration(formData)
      } else {
        this.createRegistration(formData)
      }
    } else {
      this.markFormGroupTouched()
    }
  }

  private createRegistration(formData: CourseRegister): void {
    this.courseRegisterService.createRegistration(formData).subscribe({
      next: (response) => {
        this.showMessage("Registration created successfully!", "success")
        this.loadRegistrations()
        this.resetForm()
        this.isLoading = false
      },
      error: (error) => {
        console.error("Error creating registration:", error)
        this.showMessage("Error creating registration", "error")
        this.isLoading = false
      },
    })
  }

  private updateRegistration(formData: CourseRegister): void {
    this.courseRegisterService.updateRegistration(this.editingId!, formData).subscribe({
      next: (response) => {
        this.showMessage("Registration updated successfully!", "success")
        this.loadRegistrations()
        this.resetForm()
        this.isLoading = false
      },
      error: (error) => {
        console.error("Error updating registration:", error)
        this.showMessage("Error updating registration", "error")
        this.isLoading = false
      },
    })
  }

  editRegistration(registration: CourseRegister): void {
    this.isEditing = true
    this.editingId = registration.id!
    this.registrationForm.patchValue({
      full_name: registration.full_name,
      email: registration.email,
      country_code: registration.country_code,
      whatsapp_number: registration.whatsapp_number,
    })

    // Scroll to form
    document.getElementById("registration-form")?.scrollIntoView({
      behavior: "smooth",
    })
  }

  deleteRegistration(id: number): void {
    if (confirm("Are you sure you want to delete this registration?")) {
      this.courseRegisterService.deleteRegistration(id).subscribe({
        next: (response) => {
          this.showMessage("Registration deleted successfully!", "success")
          this.loadRegistrations()
        },
        error: (error) => {
          console.error("Error deleting registration:", error)
          this.showMessage("Error deleting registration", "error")
        },
      })
    }
  }

  cancelEdit(): void {
    this.resetForm()
  }

  private resetForm(): void {
    this.registrationForm.reset()
    this.isEditing = false
    this.editingId = null
  }

  private markFormGroupTouched(): void {
    Object.keys(this.registrationForm.controls).forEach((key) => {
      const control = this.registrationForm.get(key)
      control?.markAsTouched()
    })
  }

  private showMessage(message: string, type: "success" | "error"): void {
    this.message = message
    this.messageType = type
    setTimeout(() => {
      this.message = ""
    }, 5000)
  }

  // Getter methods for form validation
  get fullName() {
    return this.registrationForm.get("full_name")
  }
  get email() {
    return this.registrationForm.get("email")
  }
  get countryCode() {
    return this.registrationForm.get("country_code")
  }
  get whatsappNumber() {
    return this.registrationForm.get("whatsapp_number")
  }

  trackByFn(index: number, item: CourseRegister): number {
    return item.id || index
  }

  // Add these methods after the existing methods

  onRightClick(event: MouseEvent, registration: CourseRegister): void {
    event.preventDefault()
    this.selectedRegistration = registration
    this.contextMenuX = event.clientX
    this.contextMenuY = event.clientY
    this.showContextMenu = true

    // Close context menu when clicking elsewhere
    setTimeout(() => {
      document.addEventListener("click", this.closeContextMenu.bind(this), { once: true })
    }, 0)
  }

  closeContextMenu(): void {
    this.showContextMenu = false
    this.selectedRegistration = null
  }

  onContextMenuEdit(): void {
    if (this.selectedRegistration) {
      this.editRegistration(this.selectedRegistration)
    }
    this.closeContextMenu()
  }

  onContextMenuDelete(): void {
    if (this.selectedRegistration) {
      this.deleteRegistration(this.selectedRegistration.id!)
    }
    this.closeContextMenu()
  }

  // Add this method to handle keyboard navigation
  onKeyDown(event: KeyboardEvent): void {
    if (event.key === "Escape") {
      this.closeContextMenu()
    }
  }
}

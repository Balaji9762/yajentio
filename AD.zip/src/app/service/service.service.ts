import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface ServiceRequest {
  provider_name: string;
  service_provider_email: string;
  service_provider_contact: string;
  service_provider_address: string;
}


@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  // Get all services
  getAllServices(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/getAllService`);
  }

  // Add new service
  addService(serviceData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/saveservice`, serviceData);
  }

  // Upload service with file
  uploadService(formData: FormData): Observable<any> {
    return this.http.post(`${this.apiUrl}/uploadservice`, formData);
  }

  // Update service
  updateService(serviceId: number, serviceData: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/updateservice/${serviceId}`, serviceData);
  }

  // Delete service
  deleteService(serviceId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/deleteservice/${serviceId}`);
  }

  // Get download URL for a service
  getDownloadUrl(serviceId: number): string {
    return `${this.apiUrl}/downloadservice/${serviceId}`;
  }
}


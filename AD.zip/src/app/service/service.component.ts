import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ServiceService } from './service.service';
import { HostListener } from '@angular/core';

@Component({
  selector: 'app-service',
  standalone: false,
  templateUrl: './service.component.html',
  styleUrl: './service.component.css'
})
export class ServiceComponent implements OnInit {
  serviceForm!: FormGroup;
  tempServices: any[] = [];
  isEditMode = false;
  editingId: number | null = null;
  selectedFile: File | null = null;
  successMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private serviceApi: ServiceService
  ) {}

  ngOnInit(): void {
    this.initializeForm();
    this.getServices();
  }

  initializeForm(): void {
    this.serviceForm = this.fb.group({
      service: [''],
      provider_name: [''],
      service_provider_email: [''],
      service_provider_contact: [''],
      service_provider_address: ['']
    });
  }

  onFileSelected(event: any): void {
    this.selectedFile = event.target.files[0];
  }

  getServices(): void {
    this.serviceApi.getAllServices().subscribe(data => {
      this.tempServices = data;
    });
  }

  onSubmit(): void {
    const formValues = this.serviceForm.value;

    const formData = new FormData();
    formData.append(
      'serviceDetails',
      new Blob([JSON.stringify(formValues)], { type: 'application/json' })
    );

    if (this.selectedFile) {
      formData.append('file', this.selectedFile);
    }

    if (this.isEditMode && this.editingId !== null) {
      // PUT (Update)
      this.serviceApi.updateService(this.editingId, formValues).subscribe(() => {
        this.successMessage = 'Service updated successfully!';
        this.getServices(); // Refresh data
        this.resetForm();
        this.autoClearMessage();
      });
    } else {
      // POST (Create)
      this.serviceApi.uploadService(formData).subscribe(() => {
        this.successMessage = 'Service added successfully!';
        this.getServices(); // Refresh data
        this.resetForm();
        this.autoClearMessage();
      });
    }
  }

  editService(service: any): void {
    this.serviceForm.patchValue(service);
    this.isEditMode = true;
    this.editingId = service.service_id;
  }

  deleteService(serviceId: number): void {
    this.serviceApi.deleteService(serviceId).subscribe(() => {
      this.successMessage = 'Service deleted successfully!';
      this.getServices(); // Refresh data
      this.autoClearMessage();
    });
  }

  resetForm(): void {
    this.serviceForm.reset();
    this.selectedFile = null;
    this.isEditMode = false;
    this.editingId = null;
  }

  autoClearMessage(): void {
    setTimeout(() => {
      this.successMessage = '';
    }, 3000);
  }

  // Get the download URL
  getDownloadUrl(serviceId: number): string {
    return this.serviceApi.getDownloadUrl(serviceId);
  }

  // Check if the file URL is likely to be an image
  isImage(url: string): boolean {
    const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
    const extension = url.split('.').pop()?.toLowerCase();
    return imageExtensions.includes(extension || '');
  }

  // Hide image if it fails to load
  hideImage(event: any): void {
    event.target.style.display = 'none';
  }
  contextMenuVisible = false;
contextMenuPosition = { x: 0, y: 0 };
contextMenuItem: any = null;

openContextMenu(event: MouseEvent, item: any): void {
  event.preventDefault();
  this.contextMenuItem = item;
  this.contextMenuPosition = { x: event.clientX, y: event.clientY };
  this.contextMenuVisible = true;
}

@HostListener('document:click')
closeContextMenu(): void {
  this.contextMenuVisible = false;
}

}

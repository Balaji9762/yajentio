import { Component, type OnInit } from '@angular/core';
import {  type FormGroup,  FormBuilder, Validators } from "@angular/forms"
import { CourseDocumentService } from "./course-document.service"
import type { CourseDocument } from './course-document';


@Component({
  selector: 'app-course-docs',
  standalone: false,
  templateUrl: './course-docs.component.html',
  styleUrl: './course-docs.component.css'
})
export class CourseDocsComponent implements OnInit {
  courseDocForm!: FormGroup
  courseDocuments: CourseDocument[] = []
  isEditMode = false
  currentDocId: number | null = null
  selectedFile: File | null = null
  contextMenuVisible = false
  contextMenuPosition = { x: 0, y: 0 }
  selectedDocumentId: number | null = null
  loading = false
  error: string | null = null

  constructor(
    private fb: FormBuilder,
    private courseDocService: CourseDocumentService,
  ) {}

  ngOnInit(): void {
    this.initForm()
    this.loadCourseDocuments()
  }

  initForm(): void {
    this.courseDocForm = this.fb.group({
      course_name: ["", Validators.required],
      course_date: ["", Validators.required],
    })
  }

  loadCourseDocuments(): void {
    this.loading = true
    this.error = null

    this.courseDocService.getAllCourseDocuments().subscribe({
      next: (documents) => {
        this.courseDocuments = documents
        this.loading = false
      },
      error: (error) => {
        console.error("Error loading documents", error)
        this.error = "Failed to load documents. Please try again later."
        this.loading = false
      },
    })
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0]
    }
  }

  onSubmit(): void {
    if (this.courseDocForm.invalid) {
      alert("Please fill all required fields")
      return
    }

    // Format the date to DD-MM-YYYY as expected by the API
    const dateValue = this.courseDocForm.get("course_date")?.value
    let formattedDate = ""

    if (dateValue) {
      const date = new Date(dateValue)
      const day = String(date.getDate()).padStart(2, "0")
      const month = String(date.getMonth() + 1).padStart(2, "0")
      const year = date.getFullYear()
      formattedDate = `${day}-${month}-${year}`
    }

    // Create course data object
    const courseData = {
      course_name: this.courseDocForm.get("course_name")?.value,
      course_date: formattedDate,
    }

    this.loading = true
    this.error = null

    if (this.isEditMode && this.currentDocId) {
      this.updateCourseDocument(this.currentDocId, courseData)
    } else {
      this.createCourseDocument(courseData)
    }
  }

  createCourseDocument(courseData: any): void {
    this.courseDocService.createCourseDocument(courseData, this.selectedFile).subscribe({
      next: (response) => {
        console.log("API Response:", response)
        alert(`Document created successfully! Course ID: ${response.course_id}`)
        this.loading = false
        this.resetForm()
        this.loadCourseDocuments()
      },
      error: (error) => {
        console.error("Error creating document", error)
        this.error = "Failed to create document. Please check the console for details."
        this.loading = false
      },
    })
  }

  updateCourseDocument(id: number, courseData: any): void {
    this.courseDocService.updateCourseDocument(id, courseData, this.selectedFile).subscribe({
      next: (response) => {
        console.log("Update Response:", response)
        alert("Document updated successfully!")
        this.loading = false
        this.resetForm()
        this.loadCourseDocuments()
      },
      error: (error) => {
        console.error("Error updating document", error)
        this.error = "Failed to update document. Please check the console for details."
        this.loading = false
      },
    })
  }

  deleteCourseDocument(id: number): void {
    if (confirm("Are you sure you want to delete this document?")) {
      this.loading = true
      this.courseDocService.deleteCourseDocument(id).subscribe({
        next: (response) => {
          console.log("Delete Response:", response)
          alert("Document deleted successfully!")
          this.loading = false
          this.loadCourseDocuments()
        },
        error: (error) => {
          console.error("Error deleting document", error)
          this.error = "Failed to delete document. Please check the console for details."
          this.loading = false
        },
      })
    }
  }

  editCourseDocument(document: CourseDocument): void {
    this.isEditMode = true
    this.currentDocId = document.course_id

    // Parse the date from DD-MM-YYYY to YYYY-MM-DD for the input field
    let formattedDate = ""
    if (document.course_date) {
      const parts = document.course_date.split("-")
      if (parts.length === 3) {
        formattedDate = `${parts[2]}-${parts[1]}-${parts[0]}`
      }
    }

    this.courseDocForm.patchValue({
      course_name: document.course_name,
      course_date: formattedDate,
    })
    this.selectedFile = null
  }

  resetForm(): void {
    this.courseDocForm.reset()
    this.isEditMode = false
    this.currentDocId = null
    this.selectedFile = null
    this.error = null
  }

  downloadDocument(url: string): void {
    window.open(url, "_blank")
  }

  onRightClick(event: MouseEvent, document: CourseDocument): void {
    event.preventDefault()
    this.contextMenuVisible = true
    this.contextMenuPosition = { x: event.clientX, y: event.clientY }
    this.selectedDocumentId = document.course_id
  }

  closeContextMenu(): void {
    this.contextMenuVisible = false
  }

  handleContextMenuAction(action: "download" | "edit" | "delete"): void {
    if (!this.selectedDocumentId) return

    const document = this.courseDocuments.find((doc) => doc.course_id === this.selectedDocumentId)
    if (!document) return

    if (action === "download") {
      this.downloadDocument(document.download_url)
    } else if (action === "edit") {
      this.editCourseDocument(document)
    } else if (action === "delete") {
      this.deleteCourseDocument(this.selectedDocumentId)
    }

    this.closeContextMenu()
  }
}

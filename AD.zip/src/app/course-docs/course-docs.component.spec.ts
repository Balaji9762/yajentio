import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CourseDocsComponent } from './course-docs.component';

describe('CourseDocsComponent', () => {
  let component: CourseDocsComponent;
  let fixture: ComponentFixture<CourseDocsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CourseDocsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CourseDocsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

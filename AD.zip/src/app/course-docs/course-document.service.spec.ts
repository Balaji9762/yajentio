import { TestBed } from '@angular/core/testing';

import { CourseDocumentService } from './course-document.service';

describe('CourseDocumentService', () => {
  let service: CourseDocumentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CourseDocumentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

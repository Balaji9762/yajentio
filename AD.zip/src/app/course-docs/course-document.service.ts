import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { CourseDocument } from './course-document';
import { environment } from '../../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class CourseDocumentService {

  private apiUrl = `${environment.apiUrl}`;

  constructor(private http: HttpClient) {}

  getAllCourseDocuments(): Observable<CourseDocument[]> {
    return this.http.get<CourseDocument[]>(`${this.apiUrl}/getAllcoursedocs`)
  }

  createCourseDocument(courseData: any, file: File | null): Observable<any> {
    const formData = new FormData()

    // Convert course data to JSON string and append as "coursedocs"
    formData.append("coursedocs", JSON.stringify(courseData))

    // Append file if available
    if (file) {
      formData.append("coursedocsresume", file)
    }

    return this.http.post(`${this.apiUrl}/coursedocsupload`, formData)
  }

  updateCourseDocument(id: number, courseData: any, file: File | null): Observable<string> {
    const formData = new FormData()

    // Convert course data to JSON string and append as "coursedocs"
    formData.append("coursedocs", JSON.stringify(courseData))

    // Append file if available
    if (file) {
      formData.append("coursedocsresume", file)
    }

    // Specify responseType as 'text' to prevent JSON parsing
    return this.http.put(`${this.apiUrl}/updatedcoursedocs/${id}`, formData, { responseType: "text" })
  }

  deleteCourseDocument(id: number): Observable<string> {
    // Specify responseType as 'text' to prevent JSON parsing
    return this.http.delete(`${this.apiUrl}/deletecoursedocs/${id}`, { responseType: "text" })
  }

  downloadCourseDocument(url: string): Observable<Blob> {
    return this.http.get(url, {
      responseType: "blob",
    })
  }
}

export interface CourseDocument {
course_id: number
  course_name: string
  course_docs: string
  course_date: string
  download_url: string
}

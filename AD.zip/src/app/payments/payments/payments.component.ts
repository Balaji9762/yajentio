import { Component, OnInit } from '@angular/core';
import { PaymentsService } from './payments.service';


@Component({
  selector: 'app-payments',
  standalone: false,
  templateUrl: './payments.component.html',
  styleUrl: './payments.component.css',

})
export class PaymentsComponent  {

}

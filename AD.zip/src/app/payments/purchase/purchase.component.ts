import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import {  Purchase, PurchaseService } from './purchase.service';
import { HostListener } from '@angular/core';

@Component({
  selector: 'app-purchase',
  standalone: false,
  templateUrl: './purchase.component.html',
  styleUrl: './purchase.component.css'
})
export class PurchaseComponent implements OnInit {
  purchases: Purchase[] = [];
  purchaseForm: FormGroup;
  editMode = false;
  editPurchaseId: number | null = null;

  constructor(private fb: FormBuilder, private purchaseService: PurchaseService) {
    this.purchaseForm = this.fb.group({
      purchase_name: ['', Validators.required],
      remarks: [''],
      amount: ['', [Validators.required, Validators.pattern(/^\d+$/)]],
      status: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this.loadPurchases();
  }

  loadPurchases() {
    this.purchaseService.getAllPurchases().subscribe({
      next: (data) => this.purchases = data,
      error: (err) => console.error('Error loading purchases', err),
    });
  }

  onSubmit() {
    if (this.purchaseForm.invalid) return;

    const formValue = this.purchaseForm.value;

    if (this.editMode && this.editPurchaseId !== null) {
      this.purchaseService.updatePurchase(this.editPurchaseId, formValue).subscribe({
        next: () => {
          this.loadPurchases();
          this.resetForm();
        },
        error: (err) => console.error('Update failed', err),
      });
    } else {
      this.purchaseService.savePurchase(formValue).subscribe({
        next: (saved) => {
          this.purchases.push(saved);
          this.resetForm();
        },
        error: (err) => console.error('Save failed', err),
      });
    }
  }

  editPurchase(purchase: Purchase) {
    this.editMode = true;
    this.editPurchaseId = purchase.purchase_id!;
    this.purchaseForm.patchValue(purchase);
  }

  cancelEdit() {
    this.resetForm();
  }

  resetForm() {
    this.editMode = false;
    this.editPurchaseId = null;
    this.purchaseForm.reset();
  }

  deletePurchase(id: number) {
    if (confirm('Are you sure you want to delete this purchase?')) {
      this.purchaseService.deletePurchase(id).subscribe({
        next: () => {
          this.purchases = this.purchases.filter(p => p.purchase_id !== id);
        },
        error: (err) => console.error('Delete failed', err),
      });
    }
  }

  contextMenuVisible = false;
  contextMenuPosition = { x: 0, y: 0 };
  contextMenuPurchase: Purchase | null = null;

  onRightClick(event: MouseEvent, purchase: Purchase) {
    event.preventDefault();
    this.contextMenuVisible = true;
    this.contextMenuPosition = { x: event.clientX, y: event.clientY };
    this.contextMenuPurchase = purchase;
  }

  @HostListener('document:click')
  onGlobalClick() {
    this.contextMenuVisible = false;
  }
}

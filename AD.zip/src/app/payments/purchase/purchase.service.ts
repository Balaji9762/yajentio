import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http"
import { Observable } from "rxjs"
import { environment } from '../../../environments/environment';

export interface Purchase {
  purchase_id?: number;
  purchase_name: string;
  remarks: string;
  amount: string;
  status: string;

}
@Injectable({
  providedIn: 'root'
})
export class PurchaseService {
//  private apiUrl = 'http://3.108.126.170:8080';
private apiUrl = environment.apiUrl;
  constructor(private http: HttpClient) {}

  getAllPurchases(): Observable<Purchase[]> {
    return this.http.get<Purchase[]>(`${this.apiUrl}/getallpurchase`);
  }

  savePurchase(purchase: Purchase): Observable<Purchase> {
    return this.http.post<Purchase>(`${this.apiUrl}/savepurchase`, purchase);
  }

  updatePurchase(id: number, purchase: Purchase): Observable<Purchase> {
    return this.http.put<Purchase>(`${this.apiUrl}/updatepurchase/${id}`, purchase);
  }

  deletePurchase(id: number): Observable<{ Message: string }> {
    return this.http.delete<{ Message: string }>(`${this.apiUrl}/deletepurchase/${id}`);
  }

}

import { Component, OnInit } from '@angular/core';
import { PaymentService } from './payment.service';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

@Component({
  selector: 'app-payment',
  standalone: false,
  templateUrl: './payment.component.html',
  styleUrl: './payment.component.css'
})
export class PaymentComponent implements OnInit {
payments: any[] = [];

  constructor(private paymentService: PaymentService) {}

  ngOnInit(): void {
    this.paymentService.getPayments().subscribe((data) => {
      this.payments = data;
    });
  }
  generateSingleInvoicePDF(payment: any): void {
    const doc = new jsPDF();

    doc.setFontSize(18);
    doc.text('Payment Invoice', 14, 20);

    doc.setFontSize(12);
    doc.text(`Invoice for Payment ID: ${payment.id}`, 14, 30);

    autoTable(doc, {
      startY: 40,
      head: [['Field', 'Value']],
      body: [
        ['ID', payment.id],
        ['Amount', (payment.currency === 'INR' ? '₹' : '') + payment.amount],
        ['Currency', payment.currency],
        ['Status', payment.status],
        ['Order ID', payment.orderId],
        ['Description', payment.description],
        ['Created At', new Date(payment.createdAt).toLocaleString()]
      ],
      styles: { fontSize: 10 },
      headStyles: { fillColor: [22, 160, 133] },
    });

    doc.save(`invoice-${payment.id}.pdf`);
  }
  generateInvoicePDF(): void {
    const doc = new jsPDF();

    // Add title
    doc.setFontSize(18);
    doc.text('Payment Invoice', 14, 20);

    // Define table headers
    const headers = [['ID', 'Amount', 'Currency', 'Status', 'Order ID', 'Description', 'Created At']];

    // Create table rows from payment data
    const data = this.payments.map(payment => [
      payment.id,
      (payment.currency === 'INR' ? '₹' : '') + payment.amount,
      payment.currency,
      payment.status,
      payment.orderId,
      payment.description,
      new Date(payment.createdAt).toLocaleString()
    ]);

    // Draw table
    autoTable(doc, {
      head: headers,
      body: data,
      startY: 30,
      styles: { fontSize: 10 },
      headStyles: { fillColor: [22, 160, 133] },
    });

    // Save PDF
    doc.save('payment-invoice.pdf');
  }
}

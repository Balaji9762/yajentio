import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
//import { SignupService } from 'src/app/services/signup.service';
import { SignupService } from './signup.service';
@Component({
  selector: 'app-signup',
  standalone: false,
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent {
  signupForm: FormGroup;
  responseMessage: string = '';
  isError: boolean = false;

  constructor(private fb: FormBuilder, private signupService: SignupService) {
    this.signupForm = this.fb.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.signupForm.valid) {
      this.signupService.registerUser(this.signupForm.value).subscribe({
        next: (res) => {
          this.isError = !res.status;
          this.responseMessage = res.message;
        },
        error: (err) => {
          this.isError = true;
          this.responseMessage = 'An error occurred while registering.';
        }
      });
    }
  }
}

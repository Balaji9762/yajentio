import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CollectionService, Payment  } from './collection.service';
import { HostListener } from '@angular/core';

@Component({
  selector: 'app-collection',
  standalone: false,
  templateUrl: './collection.component.html',
  styleUrl: './collection.component.css'
})
export class CollectionComponent implements OnInit {
  paymentForm: FormGroup;
  payments: Payment[] = [];
  editingId: number | null = null;
  currencyOptions = ['INR', 'USD', 'EUR'];  // Add or modify as needed
  statusOptions = ['captured', 'capture', 'failed', 'pending'];  // Add or modify as per backend

  constructor(private fb: FormBuilder, private collectionService: CollectionService) {
    this.paymentForm = this.fb.group({
      name: [''],
      amount: [''],
      currency: ['INR'],
      status: ['capture'],
      orderId: [''],
      description: ['']
    });
  }

  ngOnInit(): void {
    this.loadPayments();
  }

  loadPayments(): void {
    this.collectionService.getAll().subscribe(data => this.payments = data);
  }

  onSubmit(): void {
    const paymentData: Payment = this.paymentForm.value;
    const request = this.editingId
      ? this.collectionService.update(this.editingId, paymentData)
      : this.collectionService.add(paymentData);

    request.subscribe(() => {
      this.paymentForm.reset({ currency: 'INR', status: 'capture' });
      this.editingId = null;
      this.loadPayments();
    });
  }

  edit(payment: Payment): void {
    this.paymentForm.patchValue(payment);
    this.editingId = payment.id!;
  }

  delete(id: number): void {
    this.collectionService.delete(id).subscribe(() => this.loadPayments());
  }
  contextMenuVisible = false;
contextMenuPosition = { x: 0, y: 0 };
contextMenuItem: Payment | null = null;

onRightClick(event: MouseEvent, payment: Payment): void {
  event.preventDefault();
  this.contextMenuItem = payment;
  this.contextMenuPosition = { x: event.clientX, y: event.clientY };
  this.contextMenuVisible = true;
}

// Optional: close menu on click anywhere else
@HostListener('document:click')
onDocumentClick(): void {
  this.contextMenuVisible = false;
}

}

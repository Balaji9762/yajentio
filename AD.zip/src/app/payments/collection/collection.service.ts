import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface Payment {
  id?: number;
  name: string;
  amount: number;
  currency: string;
  status: string;
  orderId: string;
  description: string;
  createdAt?: string;
}

export interface PaymentResponse {
  message?: string
}
@Injectable({
  providedIn: 'root'
})
export class CollectionService {

  baseUrl = environment.baseUrl;
  private apiUrl = environment.baseUrl+'http://3.108.126.170:8080';

  private api = 'http://3.108.126.170:8080';

  constructor(private http: HttpClient) {}

  getAll(): Observable<Payment[]> {
    return this.http.get<Payment[]>(`${this.api}/getAllPayment`);
  }

  add(payment: Payment): Observable<Payment> {
    return this.http.post<Payment>(`${this.api}/savePayment`, payment);
  }

  update(id: number, payment: Payment): Observable<Payment> {
    return this.http.put<Payment>(`${this.api}/updatePaymentEntity/${id}`, payment);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.api}/deletePaymentEntity/${id}`);
  }
}

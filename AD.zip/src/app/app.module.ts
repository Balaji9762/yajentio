import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, type Routes } from "@angular/router"
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { CoursesComponent } from './courses/courses.component';
import { TopicsComponent } from './topics/topics.component';
import { LoginComponent } from './login/login.component';
import { JobsComponent } from './jobs/jobs.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { HomeComponent } from './home/home.component';
import { EmployeeComponent } from './employee/employee.component';
import { PaymentsComponent } from './payments/payments.component';
import { MatTableModule } from '@angular/material/table';
import { CommonModule, DatePipe } from '@angular/common';

import { CollectionComponent } from './payments/collection/collection.component';
// Angular Material Imports
import { MatCardModule } from "@angular/material/card"
import { MatFormFieldModule } from "@angular/material/form-field"
import { MatInputModule } from "@angular/material/input"
import { MatSelectModule } from "@angular/material/select"
import { MatButtonModule } from "@angular/material/button"
import { MatSnackBarModule } from "@angular/material/snack-bar"
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatChipsModule } from '@angular/material/chips';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BlogComponent } from './blog/blog.component';
import { PurchaseComponent } from './payments/purchase/purchase.component';
import { PaymentComponent } from './payments/payment/payment.component';
import { ServiceComponent } from './service/service.component';
import { SignupComponent } from './payments/signup/signup.component';
import { CourseDocsComponent } from './course-docs/course-docs.component';
import { CourseDetailsComponent } from './course-details/course-details.component';
import { CreateUserComponent } from './home/create-user/create-user.component';

import { ContactDetailsComponent } from './contact-details/contact-details.component';
import { BranchesComponent } from './home/branches/branches.component';
import { StudentDetailsComponent } from './course-details/student-details/student-details.component';
import { CourseRegistrationComponent } from './course-details/course-registration/course-registration.component';
import { StudentDocComponent } from './course-details/student-doc/student-doc.component';
import { IntershipComponent } from './intership/intership.component';
import { CollegeinfoComponent } from './intership/collegeinfo/collegeinfo.component';
import { StudentinfoComponent } from './intership/studentinfo/studentinfo.component';
import { IntershipListComponent } from './intership/intership-list/intership-list.component';
import { AssignmentComponent } from './assignment/assignment.component';
import { ExamTestComponent } from './assignment/exam-test/exam-test.component';

const routes: Routes = [
  // { path: "home", component: HomeComponent },
  //  { path: "**", redirectTo: "" }
  // { path: "employee", component: EmployeeComponent },
  // { path: 'payments', component: PaymentsComponent }
]

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    CoursesComponent,
    TopicsComponent,
    LoginComponent,
    JobsComponent,
    HomeComponent,
    EmployeeComponent,
    PaymentsComponent,
    CollectionComponent,
    BlogComponent,
    PurchaseComponent,
    PaymentComponent,
    ServiceComponent,
    SignupComponent,
    CourseDocsComponent,
    CourseDetailsComponent,
    CreateUserComponent,
    ContactDetailsComponent,
    BranchesComponent,
    StudentDetailsComponent,
    CourseRegistrationComponent,
    StudentDocComponent,
    IntershipComponent,
    CollegeinfoComponent,
    StudentinfoComponent,
    IntershipListComponent,
    AssignmentComponent,
    ExamTestComponent,

  ],
  imports: [
    BrowserModule,
    // BrowserAnimationsModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    SidebarComponent,
    MatTableModule,
    CommonModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatIconModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatChipsModule
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }

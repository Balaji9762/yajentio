import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface Job {
experience_range: any;
job_type: any;
job_title: any;
company_name: any;
  id?: number;
  companyname: string;
  companylogourl: string;
  jobtitle: string;
  location: string;
  status: string;
  jobtype: string;
  experiencerange: string;
  level: string;
  companylogo?: any;
}
@Injectable({
  providedIn: 'root'
})
export class JobService {

  private apiUrl = environment.baseUrl+'/savelatestjob';

  private base = environment.baseUrl;

  constructor(private http: HttpClient) {}

  postJob(data: any): Observable<any> {
    return this.http.post(`${this.base}/savelatestjob`, data);
  }

  getJobs(): Observable<any> {
    return this.http.get<any>(`${this.base}/GetLatestjobs`);
  }

  updateJob(id: number, data: any): Observable<any> {
    return this.http.put(`${this.base}/updatedlatestjob/${id}`, data);
  }

  deleteJob(id: number): Observable<any> {
    return this.http.delete(`${this.base}/deletelatestjob/${id}`);
  }
}

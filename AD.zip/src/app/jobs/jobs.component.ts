import { Component, OnInit, HostListener  } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { JobService, Job } from './job.service';
@Component({
  selector: 'app-jobs',
  standalone: false,
  templateUrl: './jobs.component.html',
  styleUrl: './jobs.component.css'
})
export class JobsComponent implements OnInit  {
  jobForm!: FormGroup
  jobs: Job[] = []
  successMessage = ""
  errorMessage = ""
  editMode = false
  editJobId: number | null = null

  // Context menu properties
  showContextMenu = false
  contextMenuX = 0
  contextMenuY = 0
  selectedJob: Job | null = null

  constructor(
    private fb: FormBuilder,
    private jobService: JobService,
  ) {
    this.initForm()
  }

  ngOnInit() {
    this.loadJobs()
  }

  // Initialize the form
  initForm() {
    this.jobForm = this.fb.group({
      companyname: ["", Validators.required],
      jobtitle: ["", Validators.required],
      location: ["", Validators.required],
      status: ["Active", Validators.required],
      jobtype: ["Full Time", Validators.required],
      experiencerange: ["", Validators.required],
      level: ["", Validators.required],
      companylogourl: ['', [Validators.required, Validators.pattern('(https?://.*\.(?:png|jpg|jpeg|gif|svg))')]]

    })
  }

  // Load all jobs from the API
  loadJobs() {
    this.jobService.getJobs().subscribe({
      next: (data) => {
        this.jobs = data
      },
      error: (err) => {
        this.errorMessage = "Failed to load jobs. Please try again."
        console.error("Error loading jobs:", err)
      },
    })
  }

  // Submit the form (create or update)
  submitForm() {
    if (this.jobForm.invalid) {
      this.markFormGroupTouched(this.jobForm)
      return
    }

    const jobData = this.jobForm.value

    if (this.editMode && this.editJobId !== null) {
      // Update existing job
      this.jobService.updateJob(this.editJobId, jobData).subscribe({
        next: () => {
          this.successMessage = "Job updated successfully!"
          this.resetForm()
          this.loadJobs()
          setTimeout(() => (this.successMessage = ""), 3000)
        },
        error: (err) => {
          this.errorMessage = "Failed to update job. Please try again."
          console.error("Error updating job:", err)
        },
      })
    } else {
      // Create new job
      this.jobService.postJob(jobData).subscribe({
        next: () => {
          this.successMessage = "Job added successfully!"
          this.resetForm()
          this.loadJobs()
          setTimeout(() => (this.successMessage = ""), 3000)
        },
        error: (err) => {
          this.errorMessage = "Failed to add job. Please try again."
          console.error("Error adding job:", err)
        },
      })
    }
  }

  // Mark all form controls as touched to trigger validation
  markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach((control) => {
      control.markAsTouched()
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control)
      }
    })
  }

  // Handle right-click on job row
  onRightClick(event: MouseEvent, job: Job) {
    event.preventDefault()
    this.selectedJob = job
    this.contextMenuX = event.clientX
    this.contextMenuY = event.clientY
    this.showContextMenu = true
  }

  // Close context menu when clicking elsewhere
  @HostListener("document:click")
  closeContextMenu() {
    this.showContextMenu = false
  }

  // Edit selected job
  editJob() {
    if (this.selectedJob) {
      this.jobForm.patchValue(this.selectedJob)
      this.editJobId = this.selectedJob.id ?? null
      this.editMode = true
      this.showContextMenu = false

      // Scroll to form
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
  }

  // Delete selected job
  deleteJob() {
    if (this.selectedJob && confirm("Are you sure you want to delete this job?")) {
      this.jobService.deleteJob(this.selectedJob.id!).subscribe({
        next: () => {
          this.successMessage = "Job deleted successfully!"
          this.loadJobs()
          this.showContextMenu = false
          setTimeout(() => (this.successMessage = ""), 3000)
        },
        error: (err) => {
          this.errorMessage = "Failed to delete job. Please try again."
          console.error("Error deleting job:", err)
        },
      })
    }
  }

  // Reset form and edit state
  resetForm() {
    this.jobForm.reset({
      status: "Active",
      jobtype: "Full Time",
    })
    this.editMode = false
    this.editJobId = null
  }

  // Cancel editing
  cancelEdit() {
    this.resetForm()
  }

}

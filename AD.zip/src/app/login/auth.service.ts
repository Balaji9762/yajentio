import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = environment.apiUrl;

  private authState = new BehaviorSubject<boolean>(false);

  constructor(private http: HttpClient) {
    // Initialize the auth state
    this.authState.next(this.isLoggedIn());
  }

  signUp(data: any) {
    // Log the signup request for debugging
    console.log('Signup request:', data);

    // Ensure all required fields are included
    const signupData = {
      firstname: data.firstname,
      lastname: data.lastname,
      email: data.email,
      password: data.password
    };

    console.log('Sending signup data:', signupData);

    // Use the endpoint from the API documentation
    return this.http.post(`${this.apiUrl}/sign_up`, signupData);
  }

  login(data: any) {
    // Log the login request for debugging
    console.log('Login request:', data);

    // Ensure we have the correct data format
    const loginData = {
      email: data.email,
      password: data.password
    };

    console.log('Sending login data:', loginData);

    // Use the endpoint from the API documentation
    return this.http.post(`${this.apiUrl}/login`, loginData, {
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      responseType: 'json',
      observe: 'body'
    });
  }

  // Helper method to extract token from different response formats
  extractAuthToken(response: any): string | null {
    console.log('Extracting token from response:', response);

    if (!response) return null;

    // Handle different response formats
    if (response.token) return response.token;
    if (response.data && response.data.token) return response.data.token;
    if (response.access_token) return response.access_token;
    if (response.auth && response.auth.token) return response.auth.token;
    if (response.accessToken) return response.accessToken;
    if (response.jwt) return response.jwt;
    if (response.id_token) return response.id_token;

    // Check for nested objects that might contain the token
    if (response.data && typeof response.data === 'object') {
      const dataObj = response.data;
      if (dataObj.token) return dataObj.token;
      if (dataObj.accessToken) return dataObj.accessToken;
      if (dataObj.access_token) return dataObj.access_token;
      if (dataObj.jwt) return dataObj.jwt;
    }

    if (response.user && typeof response.user === 'object') {
      const userObj = response.user;
      if (userObj.token) return userObj.token;
      if (userObj.accessToken) return userObj.accessToken;
      if (userObj.access_token) return userObj.access_token;
    }

    // If we can't find a token in the expected places, log the issue
    console.error('Could not extract token from response:', response);
    return null;
  }

  forgotPassword(data: any) {
    // Log the forgot password request for debugging
    console.log('Forgot password request:', data);
    return this.http.post(`${this.apiUrl}/forgotpassword`, {
      email: data.email,
      newPassword: data.newPassword
    });
  }

  setLoggedIn(token: string, user?: any) {
    localStorage.setItem('auth_token', token);
    if (user) {
      localStorage.setItem('auth_user', JSON.stringify(user));
    }
    this.authState.next(true);
  }

  logout() {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('auth_user');
    this.authState.next(false);
  }

  authStateChanged(): Observable<boolean> {
    return this.authState.asObservable();
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem('auth_token');
  }
  getLoggedInUser(): any {
    const user = localStorage.getItem('auth_user');
    return user ? JSON.parse(user) : null;
  }

  getUsernameFromEmail(): string {
    const user = this.getLoggedInUser();
    return user && user.email ? user.email.split('@')[0] : '';
  }

  // Check if the backend API is reachable
  checkApiStatus() {
    // First try a simple OPTIONS request to check if the server is up
    return this.http.get(`${this.apiUrl}`, { responseType: 'text' })
      .pipe(
        catchError(error => {
          console.error('API health check failed:', error);
          return of('API unreachable');
        })
      );
  }


}

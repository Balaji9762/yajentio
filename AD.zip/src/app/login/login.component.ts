import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  currentForm: 'signup' | 'login' | 'forgot' = 'login';
  message = '';
  backgroundStyle: string = '';

  signupForm;
  loginForm;
  forgotForm;

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {
    this.signupForm = this.fb.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });

    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });

    this.forgotForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      newPassword: ['', Validators.required]
    });
  }

  switchForm(type: 'signup' | 'login' | 'forgot') {
    this.currentForm = type;
    this.message = '';
  }

  onSignup() {
    if (this.signupForm.invalid) {
      this.message = 'Please fill all required fields correctly';
      return;
    }

    this.message = 'Creating account...';

    // Log form values for debugging
    console.log('Signup form values:', this.signupForm.value);

    this.auth.signUp(this.signupForm.value).subscribe({
      next: (res: any) => {
        // Log the response for debugging
        console.log('Signup response:', res);

        if (res.status === true) {
          this.message = res.message || 'Signup successful! Please login with your credentials.';

          // Pre-fill login form with signup email
          this.loginForm.patchValue({
            email: this.signupForm.value.email
          });

          // Automatically switch to login form after successful signup
          setTimeout(() => {
            this.switchForm('login');
          }, 2000);
        } else {
          this.message = res.message || 'Signup failed. Please try again.';
        }
      },
      error: (err) => {
        console.error('Signup error:', err);

        // Check response body if available
        const errorBody = err.error || {};
        console.log('Error body:', errorBody);

        if (errorBody && errorBody.message && errorBody.message.includes('already exists')) {
          this.message = 'Email already exists. Please use a different email.';
        } else if (err.status === 400) {
          this.message = errorBody.message || 'Invalid signup data. Please check your information.';
        } else {
          this.message = errorBody.message || 'Signup failed. Please try again.';
        }
      }
    });
  }
  onLogin() {
    if (this.loginForm.invalid) {
      this.message = 'Please enter valid email and password';
      return;
    }

    this.message = 'Logging in...';

    // Log form values for debugging
    console.log('Login form values:', this.loginForm.value);

    // Get login credentials and ensure they are strings
    const email = this.loginForm.value.email || '';
    const password = this.loginForm.value.password || '';

    console.log('Attempting login with:', email);

    // Use the standard login method directly
    this.auth.login({email: email, password: password}).subscribe({
      next: (res: any) => {
        console.log('Login response:', res);

        if (res.status === true) {
          this.message = res.message || 'Login successful';

          // Store user data
          const userData = {
            email: email,
            user_id: res.data?.user_id
          };

          // Store authentication data
          this.auth.setLoggedIn(JSON.stringify(res), userData);

          // Navigate to courses page
          this.router.navigate(['/CreateUser']);
        } else {
          this.message = res.message || 'Login failed. Please try again.';
        }
      },
      error: (err) => {
        console.error('Login failed:', err);

        // Check response body if available
        const errorBody = err.error || {};
        console.log('Error body:', errorBody);

        if (errorBody && errorBody.message) {
          this.message = errorBody.message;
        } else if (err.status === 401) {
          this.message = 'Invalid email or password';
        } else if (err.status === 404 || (errorBody && errorBody.message && errorBody.message.includes('Does not exit'))) {
          this.message = 'User does not exist. Please sign up first.';
        } else {
          this.message = 'Login failed. Please try again.';
        }
      }
    });
  }




  onForgot() {
    if (this.forgotForm.invalid) {
      this.message = 'Please enter valid email and new password';
      return;
    }

    this.message = 'Processing password reset...';
    this.auth.forgotPassword(this.forgotForm.value).subscribe({
      next: (res: any) => {
        console.log('Forgot password response:', res);

        if (res.status === true) {
          this.message = res.message || 'Password reset successful! Please login with your new password.';
          // Automatically switch to login form after successful reset
          setTimeout(() => {
            this.switchForm('login');
          }, 2000);
        } else {
          this.message = res.message || 'Password reset failed. Please try again.';
        }
      },
      error: (err) => {
        console.error('Password reset error:', err);

        const errorBody = err.error || {};

        if (errorBody && errorBody.message) {
          this.message = errorBody.message;
        } else if (err.status === 404 || (errorBody && errorBody.message && errorBody.message.includes('does not exist'))) {
          this.message = 'User with this email does not exist.';
        } else {
          this.message = 'Password reset failed. Please try again.';
        }
      }
    });
  }

  logout() {
    this.auth.logout();
    this.router.navigate(['/login']);
  }
  ngOnInit() {
    this.setBackground();
  }


  setBackground() {
    const colors = [
      'linear-gradient(135deg, rgba(255, 94, 98, 0.8), rgba(255, 42, 104, 0.9))',
      'linear-gradient(135deg, rgba(58, 166, 255, 0.8), rgba(37, 87, 253, 0.9))',
      'linear-gradient(135deg, rgba(58, 66, 86, 0.8), rgba(37, 47, 63, 0.9))',
      'linear-gradient(135deg, rgba(255, 175, 189, 0.8), rgba(255, 195, 160, 0.9))'
    ];
    this.backgroundStyle = colors[Math.floor(Math.random() * colors.length)];
  }

}

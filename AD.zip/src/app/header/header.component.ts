import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../login/auth.service';

interface MenuItem {
  name: string;
  url: string;
  sub: SubMenuItem[];
}

interface SubMenuItem {
  name: string;
  url: string;
  sub?: SubMenuItem[];
}
@Component({
  selector: 'app-header',
  standalone: false,
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent implements OnInit {

  userEmail: string = '';
  @Input() isLoggedIn: boolean = false;
  profileMenuOpen: boolean = false; // Add this line

  phoneNumber = '+91-8925132650';

  socialLinks = {
    facebook: 'http://www.facebook.com/yajentiotrainingacademy', // Replace with your actual links
    linkedin: 'http://linkdin.com/yajentiotrainingacademy',
    youtube: 'http://youtube.com/yajentio',
    instagram: 'http://instagram.com/yajentiotrainingacademy',
    whatsapp: 'https://www.whatsapp.com/',
    twitter: 'http://twitter.com/yajntiotrainingacademy'
  };
  navs: MenuItem[] = [
   
    ]

    constructor(private auth: AuthService, private router: Router) {}

  ngOnInit(): void {
    // Only set isLoggedIn from auth service if it wasn't provided as an input
    if (this.isLoggedIn === false) {
      this.isLoggedIn = this.auth.isLoggedIn();
    }
    const user = this.auth.getLoggedInUser();
    this.userEmail = user?.email || '';
  }

  toggleProfileMenu() {
    this.profileMenuOpen = !this.profileMenuOpen;
  }

  logout() {
    this.auth.logout();
    this.router.navigate(['/login']);
    this.profileMenuOpen = false; // Close menu after logout
  }
}

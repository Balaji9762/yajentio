import { Component, type OnInit, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, NavigationEnd, RouterModule } from "@angular/router"
import { filter } from "rxjs/operators"
import {  MenuItem, MenuService } from './menu.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.css',
  standalone: true,
  imports: [CommonModule, RouterModule]
})
export class SidebarComponent implements OnInit {
  @Input() isLoggedIn: boolean = false;
  menuItems: MenuItem[] = []
  expandedItems: number[] = []
  loading = true
  error: string | null = null
  currentRoute = ""

  constructor(
    private menuService: MenuService,
    private router: Router,
  ) {
    this.router.events.pipe(filter((event) => event instanceof NavigationEnd)).subscribe((event: any) => {
      this.currentRoute = event.url
    })
  }

  ngOnInit(): void {
    this.fetchMenuItems()
  }

  fetchMenuItems(): void {
    this.menuService.getMenuItems().subscribe({
      next: (data) => {
        this.menuItems = data
        this.loading = false
      },
      error: (err) => {
        this.error = "Error loading menu. Please try again later."
        this.loading = false
        console.error("Error fetching menu:", err)
      },
    })
  }

  toggleExpand(index: number): void {
    const itemIndex = this.expandedItems.indexOf(index)
    if (itemIndex === -1) {
      this.expandedItems.push(index)
    } else {
      this.expandedItems.splice(itemIndex, 1)
    }
  }

  isExpanded(index: number): boolean {
    return this.expandedItems.includes(index)
  }

  isActive(route: string): boolean {
    return this.currentRoute === route
  }

  getIconClass(iconName: string | null): string {
    if (!iconName) return ""

    // Map the icon names to Material Icons
    switch (iconName) {
      case "home":
        return "home"
      case "credit_card":
        return "credit_card"
      case "store":
        return "store"
      case "account_balance":
        return "account_balance"
      case "money":
        return "payments"
      case "group":
        return "group"
      case "computer":
        return "computer"
        case "work":
        return "work"
        case "language":
        return "language"
        case "call":
        return "call"
        case "category":
        return "category"
        case "build":
        return "build"
        case "assignment":
        return "assignment"
      default:
        return iconName
    }
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http"
import { Observable } from "rxjs"
import { environment } from '../../environments/environment';
export interface MenuItem {
  md_label: string
  md_icon: string | null
  md_route: string
  md_ischildren: string
  children: MenuItem[] | null
  md_parentid: number | null
}
@Injectable({
  providedIn: 'root'
})
export class MenuService {
 
 private apiUrl = environment.baseUrl+'/menu';
  constructor(private http: HttpClient) {}

  getMenuItems(): Observable<MenuItem[]> {
    return this.http.get<MenuItem[]>(this.apiUrl)
  }
}

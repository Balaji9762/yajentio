export const environment = {
  production: true,
  apiUrl: 'http://3.108.126.170:8080/savecontact',
  baseUrl: 'http://3.108.126.170:8080',
  recaptchaSiteKey: '6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI' // Replace with your actual site key
};

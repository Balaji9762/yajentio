import { Injectable } from '@angular/core';
import  { HttpClient } from "@angular/common/http"
import { type Observable, BehaviorSubject } from "rxjs"
import  { Router } from "@angular/router"

export interface User {
  id?: number
  firstname: string
  lastname: string
  email: string
  password: string
}

export interface AuthResponse {
  status: boolean
  message: string
  data?: {
    user_id: number
    email: string
  }
}
@Injectable({
  providedIn: 'root'
})
export class AuthService {
 private baseUrl = "http://3.108.126.170:8080"
  private currentUserSubject = new BehaviorSubject<any>(null)
  public currentUser$ = this.currentUserSubject.asObservable()

  constructor(
    private http: HttpClient,
    private router: Router,
  ) {
    // Check if user is already logged in
    const userData = localStorage.getItem("currentUser")
    if (userData) {
      this.currentUserSubject.next(JSON.parse(userData))
    }
  }

  register(user: User): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.baseUrl}/signupYTA`, user)
  }

  login(email: string, password: string): Observable<AuthResponse> {
    const loginData = { email, password }
    return this.http.post<AuthResponse>(`${this.baseUrl}/loginYTA`, loginData)
  }

  forgotPassword(email: string, newPassword: string): Observable<AuthResponse> {
    const resetData = { email, newPassword }
    return this.http.post<AuthResponse>(`${this.baseUrl}/forgotpasswordYTA`, resetData)
  }

  setCurrentUser(userData: any): void {
    localStorage.setItem("currentUser", JSON.stringify(userData))
    this.currentUserSubject.next(userData)
  }

  logout(): void {
    localStorage.removeItem("currentUser")
    this.currentUserSubject.next(null)
    this.router.navigate(["/login"])
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem("currentUser")
  }

  getCurrentUser(): any {
    return this.currentUserSubject.value
  }

  // Method to redirect to home after successful authentication
  redirectToHome(): void {
    this.router.navigate(["/home"])
  }
}

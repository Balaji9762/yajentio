import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { ApiService } from '../api.service';

@Component({
  selector: 'app-application-form',
  standalone: false,
  templateUrl: './application-form.component.html',
  styleUrl: './application-form.component.scss'
})
export class ApplicationFormComponent implements OnInit {
  applicationForm: FormGroup;
  selectedFile: File | null = null;
  isSubmitting = false;
  submitSuccess = false;
  submitError = '';
  formData: { [key: string]: any } = {}; // Dynamic JSON object

   jsonData: string = ''; // Variable to store JSON output

  qualifications = [
    'High School',
    'Bachelor\'s Degree',
    'Master\'s Degree',
    'PhD',
    'Other'
  ];

  experienceYears = [
    '0-1 years',
    '1-3 years',
    '3-5 years',
    '5-8 years',
    '8+ years'
  ];

  positions = [
    'Software Developer',
    'UI/UX Designer',
    'Project Manager',
    'Business Analyst',
    'Quality Analyst'
  ];

  constructor(
    private fb: FormBuilder,
    private ApiService: ApiService
  ) {
    this.applicationForm = this.fb.group({
      enter_your_name: ['', [Validators.required]],
      enter_phone_number: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      enter_your_email: ['', [Validators.required, Validators.email]],
      gender: ['', Validators.required],
      select_qualification: ['', Validators.required],
      enter_your_current_job_role: ['', Validators.required],
      enter_your_current_ctc: ['', Validators.required],
      enter_your_soft_skills: ['', Validators.required],
      position_applying: ['', Validators.required],
      years_of_experience: ['', Validators.required],
      enter_your_training_and_certifications: ['', Validators.required],
      additionl_details: [''],
      // marketingConsent: [false]
    });
  }

  ngOnInit(): void {}

  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
      if (allowedTypes.includes(file.type)) {
        this.selectedFile = file;
      } else {
        alert('Please upload a PDF or Word document');
        event.target.value = '';
      }
    }
  }

  async onSubmit(): Promise<void> {
    if (this.applicationForm.valid) {
      this.isSubmitting = true;
      this.submitError = '';





      //const formData = new FormData();
      const formPayload = new FormData();
      Object.keys(this.applicationForm.value).forEach(key => {

      //formData.append('data', JSON.stringify(formData)); // Send JSON as a string
        // formData.append(key, this.applicationForm.value[key]);

         this.formData[key]=this.applicationForm.value[key]

         console.log("form formData show data", key);
         console.log("form formData show data", this.applicationForm.value[key]);
         //formData.append(key, this.applicationForm.value[key]);

         //formPayload.append('file', file);


      });

      console.log("form formData show data", formPayload);
      formPayload.append('job', JSON.stringify(this.formData));




      if (this.selectedFile) {
        formPayload.append('resume', this.selectedFile);
      }

      try {
        await this.ApiService.submitApplicationForm(formPayload).toPromise();
        this.submitSuccess = true;
        this.applicationForm.reset();
        this.selectedFile = null;
      } catch (error) {
        this.submitError = 'Failed to submit application. Please try again.';
        console.error('Submission error:', error);
      } finally {
        this.isSubmitting = false;
      }
    } else {
      this.markFormGroupTouched(this.applicationForm);
    }
  }

  private markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }
}

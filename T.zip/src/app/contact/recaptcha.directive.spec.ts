/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { RecaptchaDirective } from './recaptcha.directive';

describe('Directive: Recaptcha', () => {
  it('should create an instance', () => {
    const directive = new RecaptchaDirective();
    expect(directive).toBeTruthy();
  });
});

import { Component, type OnInit } from '@angular/core';
import {  FormBuilder,  FormGroup, Validators } from "@angular/forms"
import  { Router } from "@angular/router"
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent implements OnInit {
 loginForm!: FormGroup
  forgotPasswordForm!: FormGroup
  loading = false
  submitted = false
  errorMessage = ""
  successMessage = ""
  showPassword = false
  showForgotPassword = false
  forgotPasswordLoading = false
  forgotPasswordSubmitted = false

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    // If user is already logged in, redirect to home
    if (this.authService.isLoggedIn()) {
      this.router.navigate(["/home"])
      return
    }

    this.loginForm = this.formBuilder.group({
      email: ["", [Validators.required, Validators.email]],
      password: ["", [Validators.required]],
    })

    this.forgotPasswordForm = this.formBuilder.group({
      email: ["", [Validators.required, Validators.email]],
      newPassword: ["", [Validators.required, Validators.minLength(6)]],
    })
  }

  get f() {
    return this.loginForm.controls
  }
  get fp() {
    return this.forgotPasswordForm.controls
  }

  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword
  }

  toggleForgotPassword(): void {
    this.showForgotPassword = !this.showForgotPassword
    this.errorMessage = ""
    this.successMessage = ""
    this.forgotPasswordSubmitted = false
  }

  onSubmit(): void {
    this.submitted = true
    this.errorMessage = ""
    this.successMessage = ""

    if (this.loginForm.invalid) {
      return
    }

    this.loading = true
    const { email, password } = this.loginForm.value

    this.authService.login(email, password).subscribe({
      next: (response) => {
        this.loading = false
        if (response.status && response.data) {
          this.successMessage = response.message
          this.authService.setCurrentUser(response.data)
          setTimeout(() => {
            this.router.navigate(["/home"]) // Redirect to home page
          }, 1000)
        } else {
          this.errorMessage = response.message
        }
      },
      error: (error) => {
        this.loading = false
        this.errorMessage = "Login failed. Please try again."
        console.error("Login error:", error)
      },
    })
  }

  onForgotPasswordSubmit(): void {
    this.forgotPasswordSubmitted = true
    this.errorMessage = ""
    this.successMessage = ""

    if (this.forgotPasswordForm.invalid) {
      return
    }

    this.forgotPasswordLoading = true
    const { email, newPassword } = this.forgotPasswordForm.value

    this.authService.forgotPassword(email, newPassword).subscribe({
      next: (response) => {
        this.forgotPasswordLoading = false
        if (response.status) {
          this.successMessage = response.message
          setTimeout(() => {
            this.showForgotPassword = false
            this.forgotPasswordForm.reset()
            this.forgotPasswordSubmitted = false
          }, 2000)
        } else {
          this.errorMessage = response.message
        }
      },
      error: (error) => {
        this.forgotPasswordLoading = false
        this.errorMessage = "Password reset failed. Please try again."
        console.error("Forgot password error:", error)
      },
    })
  }

  navigateToRegister(): void {
    this.router.navigate(["/registers"])
  }
}

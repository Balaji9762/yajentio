import { Component } from '@angular/core';
import { CommonModule } from "@angular/common"


@Component({
  selector: 'app-c-language-training',
  standalone: false,
  templateUrl: './c-language-training.component.html',
  styleUrl: './c-language-training.component.scss'
})
export class CLanguageTrainingComponent  {
 
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-digital-marketing',
  standalone: false,
  templateUrl: './digital-marketing.component.html',
  styleUrl: './digital-marketing.component.scss'
})
export class DigitalMarketingComponent {
// You can add any component logic here if needed
services = [
  {
    category: 'Marketing Strategy',
    title: 'SEO Marketing Ideas',
    image: 'assets/images/services/digital marketing/seo.jpg'
  },
  {
    category: 'Business Planning',
    title: 'Strategy For Business',
    image: 'assets/images/services/digital marketing/strategy.jpg'
  },
  {
    category: 'Marketing Strategy',
    title: 'Social Media Marketing',
    image: 'assets/images/services/digital marketing/socialmedia.jpg'
  },
  {
    category: 'SEO Optimizations',
    title: 'Lead Optimization',
    image: 'assets/images/services/digital marketing/lead.jpg'
  }
];
}

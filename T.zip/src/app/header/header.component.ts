import { Component,type OnInit, type OnDestroy } from '@angular/core';
import  { Router } from "@angular/router"
import { Subscription } from "rxjs"
import { AuthService } from '../auth.service';
interface MenuItem {
  name: string;
  url: string;
  sub: SubMenuItem[];
}

interface SubMenuItem {
  name: string;
  url: string;
  sub?: SubMenuItem[];
}
@Component({
  selector: 'app-header',
  standalone: false,
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent implements OnInit, OnDestroy {
  phoneNumber = "+91-8925132650"
  socialLinks = {
    facebook: "http://www.facebook.com/yajentiotrainingacademy",
    linkedin: "http://linkdin.com/yajentiotrainingacademy",
    youtube: "http://youtube.com/yajentio",
    instagram: "http://instagram.com/yajentiotrainingacademy",
    whatsapp: "https://www.whatsapp.com/",
    twitter: "http://twitter.com/yajntiotrainingacademy",
  }

  // Authentication properties
  isLoggedIn = false
  userEmail = ""
  currentUser: any = null
  private authSubscription: Subscription = new Subscription()

  navs: MenuItem[] = [
    {
      name: "Home",
      url: "/home",
      sub: [],
    },
    {
      name: "About Us",
      url: "/about-us",
      sub: [],
    },
    {
      name: "Courses",
      url: "/courses",
      sub: [],
    },
    {
      name: "Services",
      url: "/services",
      sub: [
        {
          name: "Branches",
          url: "/services/branches",
        },
        {
          name: "Digital Marketing",
          url: "/services/digitalmarketing",
        },
        {
          name: "Cloud Computing",
          url: "/services/Cloud-computing",
        },
      ],
    },
    {
      name: "Jobs",
      url: "/jobs",
      sub: [],
    },
    {
      name: "Contact",
      url: "/contact",
      sub: [],
    },
  ]

  constructor(
    private authService: AuthService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    // Subscribe to authentication state changes
    this.authSubscription = this.authService.currentUser$.subscribe((user) => {
      this.isLoggedIn = !!user
      this.currentUser = user
      this.userEmail = user?.email || ""
    })
  }

  ngOnDestroy(): void {
    if (this.authSubscription) {
      this.authSubscription.unsubscribe()
    }
  }

  logout(): void {
    this.authService.logout()
    // AuthService handles redirect to login page
  }

  navigateToLogin(): void {
    this.router.navigate(["/login"])
  }

  navigateToRegister(): void {
    this.router.navigate(["/registers"])
  }
}
